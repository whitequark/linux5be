
This is the bootloader for the Linux4.BE project, a modified CyaCE version. 

Copy the autorun.exe, cyacecfg.txt and a kernel image into the same directory (preferrably on a compact flash card), and launch the exe.

To make your BE-300 autoboot into linux when you insert the CF card, copy all these files onto the CF card in the CE\R4100 directory, and make sure the loader is called autorun.exe . Please take a look at the comments in the cyacecfg.txt for details on the usage.

Portions written and copyright by Shin Takemura, Steve Hill (sjhill@plutonium.net), Bradley D. LaRonde (brad@ltc.com), Filip Onkelinx (Filip@Onkelinx.com) and probably some others...

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 

