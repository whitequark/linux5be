// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/18 21:40:21 $
// $Revision: 1.2 $
// 
// $Header: /cvsroot//ce/InspectorTux/InspectorTux.h,v 1.2 2002/02/18 21:40:21 fon Exp $
// 
// -------------------------------------------------------------------------------

#if !defined(AFX_INSPECTORTUX_H__93160660_ECA8_4A02_A47E_E53A0CA0EB0E__INCLUDED_)
#define AFX_INSPECTORTUX_H__93160660_ECA8_4A02_A47E_E53A0CA0EB0E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CInspectorTuxApp:
// See InspectorTux.cpp for the implementation of this class
//

class CInspectorTuxApp : public CWinApp
{
public:
	CInspectorTuxApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInspectorTuxApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CInspectorTuxApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSPECTORTUX_H__93160660_ECA8_4A02_A47E_E53A0CA0EB0E__INCLUDED_)
