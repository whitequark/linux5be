// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/18 21:40:22 $
// $Revision: 1.2 $
// 
// $Header: /cvsroot//ce/InspectorTux/StdAfx.h,v 1.2 2002/02/18 21:40:22 fon Exp $
// 
// -------------------------------------------------------------------------------
//

#if !defined(AFX_STDAFX_H__2AD7565D_249C_4E79_9E71_9FFE6FC784DC__INCLUDED_)
#define AFX_STDAFX_H__2AD7565D_249C_4E79_9E71_9FFE6FC784DC__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000



#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions

#if defined(_WIN32_WCE) && (_WIN32_WCE >= 211) && (_AFXDLL)
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#endif

#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__2AD7565D_249C_4E79_9E71_9FFE6FC784DC__INCLUDED_)
