// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/19 22:20:34 $
// $Revision: 1.3 $
// 
// $Header: /cvsroot//ce/InspectorTux/InspectorTuxDlg.h,v 1.3 2002/02/19 22:20:34 fon Exp $
// 
// -------------------------------------------------------------------------------

#if !defined(AFX_INSPECTORTUXDLG_H__F99B607F_41CE_463A_AB9E_AE397B9F82A3__INCLUDED_)
#define AFX_INSPECTORTUXDLG_H__F99B607F_41CE_463A_AB9E_AE397B9F82A3__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CInspectorTuxDlg dialog

class CInspectorTuxDlg : public CDialog
{
// Construction
public:
	CInspectorTuxDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CInspectorTuxDlg)
	enum { IDD = IDD_INSPECTORTUX_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInspectorTuxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CInspectorTuxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnExit();
	afx_msg void OnVideo();
	afx_msg void OnSerial();
	afx_msg void OnSysInfo();
	afx_msg void OnRam();
	afx_msg void OnAbout();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft eMbedded Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INSPECTORTUXDLG_H__F99B607F_41CE_463A_AB9E_AE397B9F82A3__INCLUDED_)
