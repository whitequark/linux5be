// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/19 22:20:34 $
// $Revision: 1.1 $
// 
// $Header: /cvsroot//ce/InspectorTux/sysinfo.cpp,v 1.1 2002/02/19 22:20:34 fon Exp $
// 
// -------------------------------------------------------------------------------

#include "stdafx.h"
#include <windows.h>



void SysInfo()
{
TCHAR tmsg[512];
char msg[512];
SYSTEM_INFO si;

   FILE *stream2;
   LPVOID PFNs[32];

   PFNs[0]=0;
   PFNs[1]=0;
   PFNs[2]=0;
   PFNs[3]=0;
   PFNs[4]=0;
   PFNs[5]=0;
   PFNs[6]=0;
   PFNs[7]=0;

   if( (stream2 = fopen( "SysInfo.txt", "w+" )) == NULL ){
		_stprintf(tmsg, _T("fopen failed"));
		MessageBox(NULL,tmsg,_T("Error"),MB_OK|MB_ICONERROR);
		return;
   }

	GetSystemInfo(&si);
	fprintf(stream2,"dwActiveProcessorMask: %x\n",si.dwActiveProcessorMask);
	fprintf(stream2,"dwOemId: %x\n",si.dwOemId);
	fprintf(stream2,"dwProcessorType: %x\n",si.dwProcessorType);
	switch (si.wProcessorArchitecture)
	{
	case PROCESSOR_ARCHITECTURE_INTEL:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_INTEL");
		break;
	case PROCESSOR_ARCHITECTURE_MIPS:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_MIPS");
		break;
	case PROCESSOR_ARCHITECTURE_ALPHA:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_ALPHA");
		break;
	case PROCESSOR_ARCHITECTURE_PPC:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_PPC");
		break;
	case PROCESSOR_ARCHITECTURE_UNKNOWN:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_UNKNOWN");
		break;
	default:
		sprintf(msg,"PROCESSOR_ARCHITECTURE_UNKNOWN(2)");
		break;
	}
	fprintf(stream2,"wProcessorArchitecture: %s\n",msg);
	fprintf(stream2,"wProcessorLevel: %x\n",si.wProcessorLevel);
	fprintf(stream2,"wProcessorRevision: %x\n",si.wProcessorRevision);
	fprintf(stream2,"MinAppAddr: %x\n",si.lpMinimumApplicationAddress);
	fprintf(stream2,"MinAppAddr: %x\n",si.lpMaximumApplicationAddress);
	fprintf(stream2,"PageSize: %x\n",si.dwPageSize);
	fprintf(stream2,"dwAllocationGranularity: %x\n",si.dwAllocationGranularity);

	fprintf(stream2,"sizeof(char): %x\n",sizeof(char));
	fprintf(stream2,"sizeof(short): %x\n",sizeof(short));
	fprintf(stream2,"sizeof(int): %x\n",sizeof(int));
	fprintf(stream2,"sizeof(long): %x\n",sizeof(long));
	fprintf(stream2,"sizeof(void *): %x\n",sizeof(void *));
	fclose(stream2);
	_stprintf(tmsg, _T("Created 'SysInfo.txt'"));
	MessageBox(NULL,tmsg,_T("Info"),MB_OK|MB_ICONINFORMATION);

}


