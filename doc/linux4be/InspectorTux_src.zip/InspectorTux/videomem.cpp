// Project: Linux4.BE
// Copyright � 2002 Filip Onkelinx
//
// http://www.linux4.BE/
// filip@linux4.BE
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. 
//
// 
// $Workfile: $  
// $Author: fon $  
// $Date: 2002/02/19 22:20:34 $
// $Revision: 1.2 $
// 
// $Header: /cvsroot//ce/InspectorTux/videomem.cpp,v 1.2 2002/02/19 22:20:34 fon Exp $
// 
// -------------------------------------------------------------------------------

#include "stdafx.h"

#ifdef __cplusplus
extern "C"
{
#endif
	
BOOL LockPages (
LPVOID lpvAddress,
DWORD cbSize,
PDWORD pPFNs,
int fOptions );

BOOL UnlockPages (
LPVOID lpvAddress,
DWORD cbSize );

BOOL SetKMode (
BOOL fMode );   // TRUE enters kernel mode 

BOOL VirtualCopy(LPVOID, LPVOID, DWORD, DWORD);

#ifdef __cplusplus

}

#endif

void DrawPixels()
{
TCHAR msg[512];		
LPVOID lpv;
BOOL bRet; 
unsigned short *vbuff; 
unsigned short x,y;
unsigned long size;
long addr;

size=256*640*3;

    addr=0x0a200000;

	lpv = VirtualAlloc(0, size, MEM_RESERVE, PAGE_NOACCESS); 
	bRet = VirtualCopy(lpv, (LPVOID)(addr >> 8), size, PAGE_READWRITE | PAGE_NOCACHE | PAGE_PHYSICAL); 
	if (bRet)
	{

		// x: 0-240, y: 0-640
		vbuff = (unsigned short *)lpv;		
		for (y=0;y<105;y=y++)
		{
			for (x=0;x<80;x++)
			{
				vbuff[256*y+x]=0xF800;  //RED
			}
		}
		for (y=105;y<210;y=y++)
		{
			for (x=80;x<160;x++)
			{
				vbuff[256*y+x]=0x07e0;  //GREEN
			}
		}
		for (y=210;y<320;y=y++)
		{
			for (x=160;x<240;x++)
			{
				vbuff[256*y+x]=0x001F;  //BLUE
			}
		}

	}
	else
	{
				_stprintf(msg, _T("VirtualCopy Failed"));
				MessageBox(NULL,msg,NULL,MB_OK);
	}
	VirtualFree(lpv,0,MEM_RELEASE);
}

