#include <windows.h>
#include <stdio.h>

#include "../include/xkernel.h"
#include "../examples/moddump/include/Dumpper.h"

void
KdbgDumpPageFlags(unsigned int access)
{
	while(access)
	{
		switch(access)
		{
		case PAGE_NOACCESS:
			printf("PAGE_NOACCESS");
			access &= ~PAGE_NOACCESS;
			break;
		case PAGE_READONLY:
			printf("PAGE_READONLY");
			access &= ~PAGE_READONLY;
			break;
		case PAGE_READWRITE:
			printf("PAGE_READWRITE");
			access &= ~PAGE_READWRITE;
			break;
		case PAGE_WRITECOPY:
			printf("PAGE_WRITECOPY");
			access &= ~PAGE_WRITECOPY;
			break;
		case PAGE_EXECUTE:
			printf("PAGE_EXECUTE");
			access &= ~PAGE_EXECUTE;
			break;
		case PAGE_EXECUTE_READ:
			printf("PAGE_EXECUTE_READ");
			access &= ~PAGE_EXECUTE_READ;
			break;
		case PAGE_EXECUTE_READWRITE:
			printf("PAGE_EXECUTE_READWRITE");
			access &= ~PAGE_EXECUTE_READWRITE;
			break;
		case PAGE_EXECUTE_WRITECOPY:
			printf("PAGE_EXECUTE_WRITECOPY");
			access &= ~PAGE_EXECUTE_WRITECOPY;
			break;
		case PAGE_GUARD:
			printf("PAGE_GUARD");
			access &= ~PAGE_GUARD;
			break;
		case PAGE_NOCACHE:
			printf("PAGE_NOCACHE");
			access &= ~PAGE_NOCACHE;
			break;
		case PAGE_PHYSICAL:
			printf("PAGE_PHYSICAL");
			access &= ~PAGE_PHYSICAL;
			break;
		}

		if(access) printf("|");
	}
}

void
KdbgDumpSectionFlags(DWORD flags)
{
	if(!flags)
	{
		printf("      IMAGE_SCN_TYPE_REGULAR");
		return;
	}
	
	while(flags)
	{
		if(flags & IMAGE_SCN_TYPE_DUMMY)
		{
			printf("      IMAGE_SCN_TYPE_DUMMY");
			flags &= ~IMAGE_SCN_TYPE_DUMMY;
			goto loop;
		}
		if(flags & IMAGE_SCN_TYPE_NO_LOAD)
		{
			printf("      IMAGE_SCN_TYPE_NO_LOAD");
			flags &= ~IMAGE_SCN_TYPE_NO_LOAD;
			goto loop;
		}
		if(flags & IMAGE_SCN_TYPE_GROUPED)
		{
			printf("      IMAGE_SCN_TYPE_GROUPED");
			flags &= ~IMAGE_SCN_TYPE_GROUPED;
			goto loop;
		}
		if(flags & IMAGE_SCN_TYPE_NO_PAD)
		{
			printf("      IMAGE_SCN_TYPE_NO_PAD");
			flags &= ~IMAGE_SCN_TYPE_NO_PAD;
			goto loop;
		}
		if(flags & IMAGE_SCN_TYPE_COPY)
		{
			printf("      IMAGE_SCN_TYPE_COPY");
			flags &= ~IMAGE_SCN_TYPE_COPY;
			goto loop;
		}
		if(flags & IMAGE_SCN_CNT_CODE)
		{
			printf("      IMAGE_SCN_CNT_CODE");
			flags &= ~IMAGE_SCN_CNT_CODE;
			goto loop;
		}
		if(flags & IMAGE_SCN_CNT_INITIALIZED_DATA)
		{
			printf("      IMAGE_SCN_CNT_INITIALIZED_DATA");
			flags &= ~IMAGE_SCN_CNT_INITIALIZED_DATA;
			goto loop;
		}
		if(flags & IMAGE_SCN_CNT_UNINITIALIZED_DATA)
		{
			printf("      IMAGE_SCN_CNT_UNINITIALIZED_DATA");
			flags &= ~IMAGE_SCN_CNT_UNINITIALIZED_DATA;
			goto loop;
		}
		if(flags & IMAGE_SCN_LNK_OTHER)
		{
			printf("      IMAGE_SCN_LNK_OTHER");
			flags &= ~IMAGE_SCN_LNK_OTHER;
			goto loop;
		}
		if(flags & IMAGE_SCN_LNK_INFO)
		{
			printf("      IMAGE_SCN_LNK_INFO");
			flags &= ~IMAGE_SCN_LNK_INFO;
			goto loop;
		}
		if(flags & IMAGE_SCN_LNK_OVERLAY)
		{
			printf("      IMAGE_SCN_LNK_OVERLAY");
			flags &= ~IMAGE_SCN_LNK_OVERLAY;
			goto loop;
		}
		if(flags & IMAGE_SCN_LNK_REMOVE)
		{
			printf("      IMAGE_SCN_LNK_REMOVE");
			flags &= ~IMAGE_SCN_LNK_REMOVE;
			goto loop;
		}
		if(flags & IMAGE_SCN_LNK_COMDAT)
		{
			printf("      IMAGE_SCN_LNK_COMDAT");
			flags &= ~IMAGE_SCN_LNK_COMDAT;
			goto loop;
		}
		if(flags & IMAGE_SCN_COMPRESSED)
		{
			printf("      IMAGE_SCN_COMPRESSED");
			flags &= ~IMAGE_SCN_COMPRESSED;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_1BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_1BYTES");
			flags &= ~IMAGE_SCN_ALIGN_1BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_2BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_2BYTES");
			flags &= ~IMAGE_SCN_ALIGN_2BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_4BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_4BYTES");
			flags &= ~IMAGE_SCN_ALIGN_4BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_8BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_8BYTES");
			flags &= ~IMAGE_SCN_ALIGN_8BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_16BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_16BYTES");
			flags &= ~IMAGE_SCN_ALIGN_16BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_32BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_32BYTES");
			flags &= ~IMAGE_SCN_ALIGN_32BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_ALIGN_64BYTES)
		{
			printf("      IMAGE_SCN_ALIGN_64BYTES");
			flags &= ~IMAGE_SCN_ALIGN_64BYTES;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_DISCARDABLE)
		{
			printf("      IMAGE_SCN_MEM_DISCARDABLE");
			flags &= ~IMAGE_SCN_MEM_DISCARDABLE;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_NOT_CACHED)
		{
			printf("      IMAGE_SCN_MEM_NOT_CACHED");
			flags &= ~IMAGE_SCN_MEM_NOT_CACHED;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_NOT_PAGED)
		{
			printf("      IMAGE_SCN_MEM_NOT_PAGED");
			flags &= ~IMAGE_SCN_MEM_NOT_PAGED;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_SHARED)
		{
			printf("      IMAGE_SCN_MEM_SHARED");
			flags &= ~IMAGE_SCN_MEM_SHARED;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_EXECUTE)
		{
			printf("      IMAGE_SCN_MEM_EXECUTE");
			flags &= ~IMAGE_SCN_MEM_EXECUTE;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_READ)
		{
			printf("      IMAGE_SCN_MEM_READ");
			flags &= ~IMAGE_SCN_MEM_READ;
			goto loop;
		}
		if(flags & IMAGE_SCN_MEM_WRITE)
		{
			printf("      IMAGE_SCN_MEM_WRITE");
			flags &= ~IMAGE_SCN_MEM_WRITE;
			goto loop;
		}
loop:
		printf("\n");
	}
}

void
KdbgDumpObjectType(BYTE objType)
{
	switch(objType)
	{
	case EXP:
		printf("EXP - Export Table");
		break;
	case IMP:
		printf("IMP - Import Table");
		break;
	case RES:
		printf("RES - Resource Table");
		break;
	case EXC:
		printf("EXC - Exception Table");
		break;
	case SEC:
		printf("SEC - Security Table");
		break;
	case FIX:
		printf("FIX - Fixup Table");
		break;
	case DEB:
		printf("DEB - Debug Table");
		break;
	case IMD:
		printf("IMD - Image Description Table");
		break;
	case MSP:
		printf("MSP - Machine Specific Table");
		break;
	case TLS:
		printf("TLS - Thread Local Storage");
		break;
	case CBK:
		printf("CBK - Callbacks");
		break;
	}
	
	return;
}

void
KdbgDumpImports(struct ImpHdr* impHdrPtr)
{
	if( ((DWORD)impHdrPtr - KernelRamBase) == 0 ) return; // not a valid pointer
	
	printf("   imp_dllname = %08X  imp_timestamp = %08X\n",
		impHdrPtr->imp_dllname,
		impHdrPtr->imp_timestamp);

	printf("   imp_address = %08X  imp_lookup    = %08X  imp_forwarder  = %08X\n",
		impHdrPtr->imp_address,
		impHdrPtr->imp_lookup,
		impHdrPtr->imp_forwarder);

	return;
}

void
KdbgDumpExportHeader(struct ExpHdr* expHdrPtr)
{
	printf("   exp_dllname   = %08X  exp_vermajor = %08X  exp_verminor = %08X\n",
		expHdrPtr->exp_dllname,
		expHdrPtr->exp_vermajor,
		expHdrPtr->exp_verminor);

	printf("   exp_timestamp = %08X  exp_flags    = %08X\n",
		expHdrPtr->exp_timestamp,
		expHdrPtr->exp_flags);

	printf("   exp_ordbase   = %08X  exp_eatcnt   = %08X  exp_namecnt  = %08X\n",
		expHdrPtr->exp_ordbase,
		expHdrPtr->exp_eatcnt,
		expHdrPtr->exp_namecnt);

	printf("   exp_eat       = %08X  exp_name     = %08X  exp_ordinal  = %08X\n",
		expHdrPtr->exp_eat,
		expHdrPtr->exp_name,
		expHdrPtr->exp_ordinal);
}

void
KdbgDumpExportFunctions(DWORD BasePtr, struct ExpHdr* expHdrPtr)
{
	ULONG addrIndex,ordIndex;
	WORD* ordTable;
	DWORD* nameTable;
	char* namePointer;
	DWORD* addressTable;

	ordTable = (WORD*)KernelVirt2Ram(BasePtr + expHdrPtr->exp_ordinal);
	nameTable = (DWORD*)KernelVirt2Ram(BasePtr + expHdrPtr->exp_name);
	addressTable = (DWORD*)KernelVirt2Ram(BasePtr + expHdrPtr->exp_eat);

	for(addrIndex = 0; addrIndex < expHdrPtr->exp_eatcnt; addrIndex++)
	{
		/* 
		 * Determine if the function is exported by name. Search the ordinal table
		 * for a value that matches our current index into the address table. If
		 * one is found, then the function has an export name entry in the coorisponding 
		 * name table with the same index as the index of the ordinal table in which
		 * we just matched
		*/
		namePointer = NULL;
		for(ordIndex = 0; ordIndex < expHdrPtr->exp_namecnt; ordIndex++)
		{
			if( ((WORD)ordTable[ordIndex]) == addrIndex )
			{	//we found a match
				namePointer = (char*)KernelVirt2Ram(BasePtr + nameTable[ordIndex]);
				break;
			}
		}

		if(addressTable[addrIndex] == 0)
		{
			// it seem that this ordinal is being reserved. There is no
			// function at this ordinal, so dont try to print one
			printf("         !! RESERVED !!      @%-5d", 
				addrIndex + expHdrPtr->exp_ordbase);
		}
		else
		{
			printf("       %08X (%08X)   @%-5d",
				addressTable[addrIndex],
				KernelVirt2Phys(BasePtr + addressTable[addrIndex]),
				addrIndex + expHdrPtr->exp_ordbase);
		}

		if(namePointer)
		{
			printf("   (%08X) %s\n",
				ZeroRamAddr(namePointer),
				namePointer);

		}
		else
			printf("\n");		//no name just ordinal

		//dumpFunction(BasePtr + addressTable[addrIndex]);

	}
}

void
KdbgDumpExports(DWORD BasePtr, struct ExpHdr* expHdrPtr)
{
	KdbgDumpExportHeader(expHdrPtr);

	printf("      Entry Point           Ord      Name\n");
	
	KdbgDumpExportFunctions(BasePtr, expHdrPtr);

	return;
}

void
KdbgDumpExeExports(PPROCESS pProc)
{
	struct ExpHdr* expHdrPtr;
	expHdrPtr = (struct ExpHdr*) MAKERAMPTR(KernelVirt2Phys((DWORD)pProc->BasePtr + (DWORD)pProc->e32.e32_unit[EXP].rva));

	if ( ZeroRamAddr(expHdrPtr) == 0 ) return; // invalid expHdrPtr
	
	KdbgDumpExports((DWORD)pProc->BasePtr, expHdrPtr);

	return;
}

void
KdbgDumpDllExports(PMODULE pMod)
{
	struct ExpHdr* expHdrPtr;
	expHdrPtr = (struct ExpHdr*) MAKERAMPTR(KernelVirt2Phys((DWORD)pMod->BasePtr + (DWORD)pMod->e32.e32_unit[EXP].rva));

	if ( ZeroRamAddr(expHdrPtr) == 0 ) return; // invalid expHdrPtr
	
	KdbgDumpExports((DWORD)pMod->BasePtr, expHdrPtr);

	return;
}

void
KdbgDumpExceptionTable(PRUNTIME_FUNCTION rtChain, LONG size)
{
	//PRUNTIME_FUNCTION rtChain;

	int fCnt = (size / sizeof(RUNTIME_FUNCTION));
	//rtChain = (PRUNTIME_FUNCTION) MAKERAMPTR(KernelVirt2Phys(exceptionTableHdr->rva));

	if( ((DWORD)rtChain - KernelRamBase) == 0 ) return; // not a valid pointer

	for(int index=0; index<fCnt; index++)
	{
		printf("   BeginAddress  = %08X  EndAddress   = %08X  HandlerData  = %08X\n",
			rtChain->BeginAddress,
			rtChain->EndAddress,
			rtChain->HandlerData);

		printf("   ExceptionHandler = %08X    PrologEndAddress    = %08X\n",
			rtChain->ExceptionHandler,
			rtChain->PrologEndAddress);
		
		rtChain++;
	}
	return;
}


int
KdbgDumpModuleObject(struct o32_lite* o32ptr, BYTE objType)
{
	struct o32_lite* optr;
	DWORD realaddress, dataptr;

	if(o32ptr == NULL) return -1;
	
	optr = (struct o32_lite*) MAKERAMPTR( KernelVirt2Phys( (DWORD)o32ptr ) );
	
	printf(" objPtr%i = %08X (%08X)\n", objType, o32ptr, optr);

	realaddress = (DWORD) MAKERAMPTR(KernelVirt2Phys(optr->o32_realaddr));

	printf("   o32_rva     = %08X    o32_realaddress = %08X (%08X)\n", 
		optr->o32_rva,
		optr->o32_realaddr,
		realaddress);

	printf("   o32_vsize   = %08X    o32_psize       = %08X\n",
		optr->o32_vsize,
		optr->o32_psize);
	
	printf("   o32_access  = %08X\n      ", optr->o32_access);
	KdbgDumpPageFlags(optr->o32_access);
	printf("\n");

	printf("   o32_flags   = %08X\n", optr->o32_flags);
	KdbgDumpSectionFlags(optr->o32_flags);
	//printf("\n");

	dataptr = (DWORD) MAKERAMPTR(KernelVirt2Phys(optr->o32_dataptr));
	
	printf("   o32_dataptr = %08X (%08X)\n",
		optr->o32_dataptr,
		dataptr);

	return 0;
}
