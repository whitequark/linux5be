#include <windows.h>
#include <tchar.h>
#include "../include/xcoredll.h"

pfCacheSync		CacheSync;
pfGetStdioPathW GetStdioPathW;

int 
XCoreDllInit(void)
{
	HINSTANCE hCoreDll;
	
	hCoreDll = LoadLibrary(_T("coredll.dll"));

	CacheSync = (pfCacheSync)GetProcAddress(hCoreDll,_T("CacheSync"));
//	if (!CacheSync) return -1;

	GetStdioPathW = (pfGetStdioPathW)GetProcAddress(hCoreDll,_T("GetStdioPathW"));
//	if (!GetStdioPathW) return -1;

	return 0;
}