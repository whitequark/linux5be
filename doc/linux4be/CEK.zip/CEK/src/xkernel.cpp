#include <windows.h>
#include <fcntl.h>
#include <io.h>

#include "../../DynBase/include/DynStr.h"
#include "../../DynBase/include/DynWStr.h"
#include "../include/cek.h"

#include "../include/xcoredll.h"
#include "../include/xkernel.h"

DWORD			KernelRamBase;
PKDATASTRUCT	KernelKDataStructPtr;

DWORD KernelVirt2Phys(DWORD addr)
{
	PSECTION		sectionPtr; 
	PMEMBLOCK		blockPtr;
	DWORD			pageFramePtr;
	DWORD			section, block, page;
	DWORD			physAddr;

	if ( addr >= KSEG0_BASE ) 
	{
		/* 
		 * addr is a physical kseg reference so it mapped directly to RAM and
		 * no conversion is needed. addr[30:0] map directly to a physical address
		*/
		DWORD ret = addr & (MAX_RAM_SIZE-1);
		return (ret);
	}

	section =  addr >> VA_SECTION;
	block	= (addr >> VA_BLOCK) & BLOCK_MASK;
	page	= (addr >> VA_PAGE) & PAGE_MASK;

	// get pointer to section
	sectionPtr = (PSECTION) KernelVirt2Phys((DWORD)KernelKDataStructPtr->SectionTable[section]);
	if(sectionPtr == 0) return 0;

	// get pointer to block
	blockPtr = (PMEMBLOCK) KernelVirt2Phys((DWORD)((MAKERAMPTR(sectionPtr))[block]) );
	if(blockPtr == 0) return 0;

	// get pointer to page frame
	pageFramePtr = ((PMEMBLOCK)MAKERAMPTR(blockPtr))->aPages[page];
	if(pageFramePtr == 0) return 0;

	// merge PFN with address offset to get physical address
	physAddr = ((pageFramePtr << PFN_SHIFT) & PFN_MASK) | (addr & 0xFFF);

	return physAddr;
}

PMODULE
KernelFindModuleA(PKPAGE pKDataPage, char *modName)
{
	//PKPAGE	kPage	= (PKPAGE)MakeRamPtr(KernelPageAbsolute);;
	PMODULE pMod	= (PMODULE) pKDataPage->KData.KInfoTable[KINX_MODULES];

	while (pMod != 0) 
	{
		DynWStr currentModuleName;		//modual name is a wide character string

		pMod = (PMODULE)MAKERAMPTR(KernelVirt2Phys((DWORD)pMod));

		currentModuleName = (WCHAR*)MAKERAMPTR(KernelVirt2Phys((DWORD)pMod->name));;

		//if (  modName == currentModuleName )
		if (  strcmp(modName,(char*)currentModuleName) == 0 )
		{
			return pMod;
		}

	    pMod = pMod->next;
	}

	return (PMODULE)NULL;
}


PMODULE
KernelFindModuleW(PKPAGE pKDataPage, wchar_t *modName)
{
	return KernelFindModule(pKDataPage, (char*)DynWStr(modName));
}

PMODULE
KernelFindModuleFirst(PKPAGE pKDataPage)
{
	PMODULE pMod	= (PMODULE) pKDataPage->KData.KInfoTable[KINX_MODULES];
	return (PMODULE)MAKERAMPTR(KernelVirt2Phys((DWORD)pMod));
}

PMODULE
KernelFindModuleNext(PMODULE pModCurrent)
{
	pModCurrent = pModCurrent->next;

	if (!pModCurrent) return 0;

	return (PMODULE)MAKERAMPTR(KernelVirt2Phys((DWORD)pModCurrent));
}

PPROCESS
KernelFindProcessFirst(PKPAGE pKDataPage)
{
	PPROCESS pProc	= (PPROCESS) pKDataPage->KData.KInfoTable[KINX_PROCARRAY];
	return (PPROCESS)MAKERAMPTR(KernelVirt2Phys((DWORD)pProc));
}

PPROCESS
KernelFindProcessNext(PPROCESS pProcCurrent)
{
	pProcCurrent++;

	if (!pProcCurrent) return 0;

	return (PPROCESS)MAKERAMPTR(KernelVirt2Phys((DWORD)pProcCurrent));
}

PKPAGE
KernelInitData(char *pszMemFileName)
{
	LONG	dwFileHandle = (LONG)-1;
	HANDLE	hFileMapping = INVALID_HANDLE_VALUE;

#if defined(KERNEL_USING_RAMFILE)

	if (pszMemFileName != NULL)
	{
		dwFileHandle = _get_osfhandle( _open(pszMemFileName ,_O_RDONLY) );
		if ( dwFileHandle == (LONG)-1 ) 
			return NULL;

		hFileMapping = CreateFileMappingA( (HANDLE) dwFileHandle,
										   0,
										   PAGE_READONLY,
										   0,
										   0,
										   pszMemFileName);
		if ( hFileMapping == INVALID_HANDLE_VALUE ) 
		{
			_close(dwFileHandle);
			dwFileHandle = (LONG)-1;
			return NULL;
		}
		
		KernelRamBase = (DWORD) MapViewOfFile(hFileMapping,FILE_MAP_READ,0,0,0);
		if (KernelRamBase == NULL)
		{
			_close(dwFileHandle);
			dwFileHandle = (LONG)-1;
			CloseHandle(hFileMapping);
			hFileMapping = INVALID_HANDLE_VALUE;
			return NULL;
		}
	}
	else
		return NULL;

#else

	KernelRamBase = (DWORD)KSEG0_BASE;   /* base of cached kernel physical   */
	
#endif

	KernelKDataStructPtr = &( ((PKPAGE)MAKERAMPTR(KernelPageAbsolute))->KData );
	
	// initialize coredll extensions
	XCoreDllInit();

	return ( (PKPAGE) MAKERAMPTR(KernelPageAbsolute) );

}

BYTE*
KernelCopyRam (BYTE* tgtBuffer, DWORD ramStart, ULONG count, BOOL cached)
{
    BYTE*	retBuff;
	DWORD   ramCopyBase;

	if (tgtBuffer == NULL) return NULL;  // must have something to copy to.

	// range check
	if ( (ramStart+count-1) > RAM_MAX )
		return NULL;

#if defined(KERNEL_USING_RAMFILE)

	ramCopyBase = KernelRamBase;

#else
	if(cached)
		ramCopyBase = KSEG0_BASE;
	else
	{
		ramCopyBase = KSEG1_BASE;

		// make sure we "write-back" any info stored in cache
		CacheSync (CACHE_SYNC_WRITEBACK);
	}

#endif

	retBuff = (BYTE*) memcpy( tgtBuffer, (VOID*)(ramCopyBase + ramStart), count );
	
	return retBuff;
}

PPROCESS
KernelGetProcessArray(PKPAGE pKDataPage)
{
	PPROCESS pProc = (PPROCESS) pKDataPage->KData.KInfoTable[KINX_PROCARRAY];
	return (PPROCESS)MAKERAMPTR(KernelVirt2Phys((DWORD)pProc));
}