#if !defined(CEINTR_H_)
#define CEINTR_H_

#define SYSINTR_MAX_DEVICES 32


//
// Define MIPS exception handling structures and function prototypes.
//
// Function table entry structure definition.
//

typedef struct _RUNTIME_FUNCTION 
{
    ULONG BeginAddress;
    ULONG EndAddress;
    DWORD ExceptionHandler;
    PVOID HandlerData;
    ULONG PrologEndAddress;
} RUNTIME_FUNCTION, *PRUNTIME_FUNCTION;

#endif  // !defined(CEINTR_H_)