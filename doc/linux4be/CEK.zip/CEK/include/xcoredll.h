#if !defined(XCOREDLL_H)
#define XCOREDLL_H

int XCoreDllInit(void);

/* Flags for CacheSync */
#define CACHE_SYNC_DISCARD      0x001   /* write back & discard all cached data */
#define CACHE_SYNC_INSTRUCTIONS 0x002   /* discard all cached instructions */
#define CACHE_SYNC_WRITEBACK	0x004	/* write back but don't discard data cache*/

//VOID CacheSync ( int flags );
typedef VOID (WINAPI *pfCacheSync)(int flags);
extern pfCacheSync CacheSync;

typedef BOOL (WINAPI *pfGetStdioPathW)(DWORD id,PWSTR pwszBuf,LPDWORD lpdwLen);
extern pfGetStdioPathW GetStdioPathW;
#endif