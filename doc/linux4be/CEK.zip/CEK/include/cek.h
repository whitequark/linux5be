#if !defined(CEK_H)
#define CEK_H

#include "cetypes.h"

//#define MAX_RAM_SIZE	0x00FFFFFF
#define MAX_RAM_SIZE	0x20000000
/*
 * Define address space layout as defined by MIPS memory management.
*/
#define KUSEG_BASE 0x0          /* base of user segment             */
#define KSEG0_BASE 0x80000000   /* base of cached kernel physical   */
#define KSEG1_BASE 0xa0000000   /* base of uncached kernel physical */
#define KSEG2_BASE 0xc0000000	/* base of cached kernel virtual    */

#include "cevmem.h"
#include "ceintr.h"

typedef struct Process PROCESS;
typedef PROCESS *PPROCESS;

typedef struct Thread THREAD;
typedef THREAD *PTHREAD;

typedef struct Module MODULE;
typedef MODULE *PMODULE, *LPMODULE;

typedef ULONG ACCESSKEY;
typedef ULONG ACCESSLOCK;

#define PAGE_NOACCESS          0x01     
#define PAGE_READONLY          0x02     
#define PAGE_READWRITE         0x04     
#define PAGE_WRITECOPY         0x08     
#define PAGE_EXECUTE           0x10     
#define PAGE_EXECUTE_READ      0x20     
#define PAGE_EXECUTE_READWRITE 0x40     
#define PAGE_EXECUTE_WRITECOPY 0x80     
#define PAGE_GUARD            0x100     
#define PAGE_NOCACHE          0x200     
#define PAGE_PHYSICAL		  0x400
#define PAGE_WRITECOMBINE     0x400     
#define MEM_COMMIT           0x1000     
#define MEM_RESERVE          0x2000     
#define MEM_DECOMMIT         0x4000     
#define MEM_RELEASE          0x8000     
#define MEM_FREE            0x10000     
#define MEM_PRIVATE         0x20000     
#define MEM_MAPPED          0x40000     
#define MEM_RESET           0x80000     
#define MEM_TOP_DOWN       0x100000     
#define MEM_AUTO_COMMIT    0x200000
#define MEM_4MB_PAGES    0x80000000     
#define SEC_FILE           0x800000     
#define SEC_IMAGE         0x1000000     
#define SEC_VLM           0x2000000     
#define SEC_RESERVE       0x4000000     
#define SEC_COMMIT        0x8000000     
#define SEC_NOCACHE      0x10000000     
#define MEM_IMAGE         SEC_IMAGE     

#define PAGE_SIZE 4096
#define PAGES_PER_BLOCK  (0x10000 / PAGE_SIZE)

/* 
 * Memory Block
 *   This structure maps a 64K block of memory. All memory reservations must begin on a 64k 
 *   boundary.
 */
typedef struct MemBlock                     /*           Map of 64K Block Of Memory          */
{                                           /* --------------------------------------------- */
    ACCESSLOCK	alk;						/* 00: key code for this set of pages            */
    BYTE		cUses;						/* 04: # of page table entries sharing this leaf */
    BYTE		flags;						/* 05: mapping flags                             */
    SHORT       ixBase;						/* 06: first block in region                     */
    SHORT		hPf;						/* 08: handle to pager                           */
    SHORT		cLocks;						/* 0A: lock count                                */
    DWORD       aPages[PAGES_PER_BLOCK];	/* 0C: entrylo values  (list of PFN's)           */
} MEMBLOCK, *PMEMBLOCK;

typedef MEMBLOCK *SECTION[BLOCK_MASK+1];
typedef SECTION *PSECTION;

typedef struct PROXY *LPPROXY;

#define PRIORITY_LEVELS_HASHSIZE 32

typedef struct 
{
	WORD	wPool;
	WCHAR	name[MAX_PATH];	/* name of item */
} Name, * LPName;

typedef struct EVENT *LPEVENT;

typedef struct EVENT 
{
	HANDLE hNext;									/* Next event in list                   */
	LPPROXY pProxList;
	LPPROXY pProxHash[PRIORITY_LEVELS_HASHSIZE];
	BYTE onequeue;
	BYTE state;										/* TRUE: signalled, FALSE: unsignalled  */
	BYTE manualreset;								/* TRUE: manual reset, FALSE: autoreset */
	BYTE bMaxPrio;
	Name *name;										/* 0x50: points to name of event        */
	LPPROXY pIntrProxy;
} EVENT;


#define NUM_SYS_HANDLES  32

typedef BOOL (*PFNKDBG)(DWORD dwCause, PTHREAD pictx);

#include "cekmips.h"

#if !defined(_DBGPARAM)
	/*
	 * The name of the module is used to look for zone initialization information in the host PC
	 * registry. Zone names are displayed by the control app (eg shell) which allows the user to
	 * dynamically set zones.
	*/
	typedef struct _DBGPARAM            /* DEBUG ZONE information structure */
	{                                   /* -------------------------------- */
		WCHAR	lpszName[32];           /* Name of module                   */
		WCHAR   rglpszZones[16][32];	/* names of zones for first 16 bits */
		ULONG   ulZoneMask;             /* Current zone Mask                */
	} DBGPARAM, *LPDBGPARAM;
#endif

#if !defined(CEOID)
	typedef DWORD CEOID;
#endif

#include "cerom.h"
#include "cepe.h"

struct Process 
{
    BYTE        procnum;    /* 00: ID of this process [ie: it's slot number] */
    BYTE		DbgActive;	/* 01: ID of process currently DebugActiveProcess'ing this process */
    BYTE		bChainDebug;/* 02: Did the creator want to debug child processes? */
    BYTE		bTrustLevel;/* 03: level of trust of this exe */
	LPPROXY		pProxList;	/* 04: list of proxies to threads blocked on this process */
    HANDLE		hProc;		/* 08: handle for this process, needed only for SC_GetProcFromPtr */
    DWORD       dwVMBase;   /* 0C: base of process's memory section, or 0 if not in use */
    PTHREAD     pTh;        /* 10: first thread in this process */
    ACCESSKEY   aky;        /* 14: default address space key for process's threads */
	LPVOID      BasePtr;    /* 18: Base pointer of exe load */
	HANDLE		hDbgrThrd;	/* 1C: handle of thread debugging this process, if any */
	LPWSTR      lpszProcName;/* 20: name of process */
	DWORD       tlsLowUsed; /* 24: TLS in use bitmask (first 32 slots) */
	DWORD       tlsHighUsed;/* 28: TLS in use bitmask (second 32 slots) */
	DWORD		pfnEH;/*2C: process exception handler (PEXCEPTION_ROUTINE)*/
	LPDBGPARAM  ZonePtr;    /* 30: Debug zone pointer */
	PTHREAD		pMainTh;	/* 34  primary thread in this process*/
	PMODULE		pmodResource;	/* 38: module that contains the resources */
	LPName		pStdNames[3]; /* 3C: Pointer to names for stdio */
	LPCWSTR		pcmdline;	/* 48: Pointer to command line */
	DWORD		dwDyingThreads;	/* 4C: number of pending dying threads */
	openexe_t   oe;			/* 50: Pointer to executable file handle */
	e32_lite    e32;        /* ??: structure containing exe header */
	o32_lite    *o32_ptr;   /* ??: o32 array pointer for exe */
	LPVOID		pExtPdata;
};

#define MAX_PROCESSES 32

// from kernel macro MapPtrInProcess
#define MapPtrInModule(Ptr, Module) (((DWORD)(Ptr)>>VA_SECTION) ? (LPVOID)(Ptr) : \
        (LPVOID)((DWORD)(Ptr)|(DWORD)Module->BasePtr))

struct Module 
{
	LPVOID		self;					/* Self pointer for validation						*/
	PMODULE		next;                   /* Next module in chain								*/
	LPWSTR		name;					/* Module name										*/
	ULONG		inuse;                  /* Bit vector of use								*/
	DWORD		calledfunc;				/* Called entry but not exit						*/
	WORD		refcnt[MAX_PROCESSES];	/* Reference count per process						*/
	DWORD		BasePtr;                /* Base pointer of dll load (not 0 based)			*/
	ULONG		DbgFlags;               /* Debug flags										*/
	LPDBGPARAM	ZonePtr;				/* Debug zone pointer								*/
	ULONG		startip;                /* 0 based entrypoint								*/
	openexe_t	oe;						/* Pointer to executable file handle				*/
	e32_lite	e32;					/* E32 header										*/
	o32_lite	*o32_ptr;				/* O32 chain ptr									*/
	ULONG		breadcrumb;
	ULONG		dwNoNotify;				/* 1 bit per process, set if notifications disabled */
	WORD		wFlags;
	BYTE		bTrustLevel;
	BYTE		bPadding;
	PMODULE		pmodResource;			/* module that contains the resources				*/
};

#include "ceintr.h"
#include "ceapi.h"

#endif  //!defined(CEK_H)