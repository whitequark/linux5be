#if !defined(CEAPI_H)
#define CEAPI_H

typedef void (*PFNVOID)();

#define NUM_SYSTEM_SETS	32

typedef struct cinfo 
{
    CHAR        acName[4];		/* 00: object type ID string (not 0 terminated) */
    UCHAR       disp;     		/* 04: type of dispatch */
    UCHAR		type;			/* 05: api handle type */
    USHORT      cMethods;		/* 06: # of methods in dispatch table */
    const PFNVOID *ppfnMethods;	/* 08: ptr to array of methods (in server address space) */
    const DWORD *pdwSig;		/* 0C: ptr to array of method signatures */
    PPROCESS   	pServer;		/* 10: ptr to server process */
} CINFO;    /* cinfo */

typedef CINFO *PCINFO;

#define DISPATCH_KERNEL     0   /* dispatch directly in kernel */
#define DISPATCH_I_KERNEL   1   /* dispatch implicit handle in kernel */
#define DISPATCH_KERNEL_PSL 2   /* dispatch as thread in kernel */
#define DISPATCH_I_KPSL     3   /* implicit handle as kernel thread */
#define DISPATCH_PSL        4   /* dispatch as user mode PSL */
#define DISPATCH_I_PSL      5   /* implicit handle as user mode PSL */


#define SH_WIN32                0
#define SH_CURTHREAD            1
#define SH_CURPROC              2
#define SH_KWIN32				3       // OBSOLETE

// Special handle indicies used for "typed" handle calls
#define HT_EVENT				4		// Event handle type
#define HT_MUTEX				5		// Mutex handle type
#define HT_APISET				6		// kernel API set handle type
#define HT_FILE					7		// open file handle type
#define HT_FIND					8		// FindFirst handle type
#define HT_DBFILE				9		// open database handle type
#define HT_DBFIND				10		// database find handle type
#define HT_SOCKET				11		// WinSock open socket handle type
#define HT_INTERFACE			12
#define HT_SEMAPHORE			13		// Semaphore handle type
#define HT_FSMAP				14		// mapped files
#define HT_WNETENUM             15      // Net Resource Enumeration

#define SH_LAST_NOTIFY			16	// Last set notified on Thread/Process Termination
#define SH_GDI                  16
#define SH_WMGR                 17
#define SH_WNET					18      // WNet APIs for network redirector
#define SH_COMM                 19      // Communications not "COM"
#define SH_FILESYS_APIS			20      // File system APIS
#define SH_SHELL                21
#define SH_DEVMGR_APIS			22		// File system device manager
#define SH_TAPI					23
#define SH_PATCHER				24

#define SH_LASTRESERVED			24

#endif  /* !defined(CEAPI_H) */