#if !defined(XKERNEL_H)
#define XKERNEL_H

#include "cek.h"

#define  PAGE_SIZE          4096
#define  RAM_MAX            0x00FFFFFF
#define  RAM_SIZE           (RAM_MAX+1)

// MakePtr is a macro that allows you to easily add two values (including
// pointers) together without dealing with C's pointer arithmetic.  It
// essentially treats the last two parameters as DWORDs.  The first
// parameter is used to typecast the result to the appropriate pointer type.
#define MAKEPTR( cast, ptr, addValue ) (cast)( (DWORD)(ptr) + (DWORD)(addValue))

#if !defined(UNDER_CE)
#	define KERNEL_USING_RAMFILE
#endif

extern DWORD	KernelRamBase;

// MakePtr is a macro that allows you to easily add to values (including
// pointers) together without dealing with C's pointer arithmetic.  It
// essentially treats the last two parameters as DWORDs.  The first
// parameter is used to typecast the result to the appropriate pointer type.
//#define MakeRamPtr(cast, ptr) MakePtr(cast, _ramBase, ptr )
#define MAKERAMPTR(ptr) MAKEPTR(DWORD*, KernelRamBase, ptr )

PKPAGE
KernelInitData(char *pszMemFileName = NULL);

DWORD
KernelVirt2Phys(DWORD addr);

# define KernelVirt2Ram(addr) \
	MAKERAMPTR(KernelVirt2Phys(addr))

#define ZeroRamAddr(addr)	((DWORD)addr - KernelRamBase)

BYTE*
KernelCopyRam (BYTE* tgtBuffer, DWORD ramStart, ULONG count, BOOL cached = TRUE);

PMODULE
KernelFindModuleA(PKPAGE pKDataPage, char *modName);

PMODULE
KernelFindModuleW(PKPAGE pKDataPage, wchar_t *modName);

#if !defined(UNICODE)
#	define KernelFindModule	KernelFindModuleA
#else
#	define KernelFindModule KernelFindModuleW
#endif

PMODULE
KernelFindModuleFirst(PKPAGE pKDataPage);

PMODULE
KernelFindModuleNext(PMODULE pModCurrent);

PPROCESS
KernelGetProcessArray(PKPAGE pKDataPage);


PPROCESS
KernelFindProcessFirst(PKPAGE pKDataPage);

PPROCESS
KernelFindModuleNext(PPROCESS pProcCurrent);


#endif  // !defined(XKERNEL_H)