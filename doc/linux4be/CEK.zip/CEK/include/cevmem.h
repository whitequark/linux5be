//	The user mode virtual address space is 2GB split into 64 32M sections
// of 512 64K blocks of 16 4K pages.
//
// Virtual address format:
//	3322222 222221111 1111 110000000000
//	1098765 432109876 5432 109876543210
//	zSSSSSS BBBBBBBBB PPPP oooooooooooo

#define SECTION_MASK	0x03F
#define BLOCK_MASK      0x1FF
#define PAGE_MASK       0x00F

// Bit offsets of block & section in a virtual address:
#define VA_SECTION      25
#define VA_BLOCK        16
#define VA_PAGE         12

#define PFN_MASK	(~(PAGE_SIZE-1) & (MAX_RAM_SIZE-1))
#define PFN_SHIFT   4

#define SECTION_SHIFT		VA_SECTION    
// secure section related defs
#define SECURE_SECTION      0x61    // VM at 0xC2XXXXXX
#define SECURE_VMBASE       (SECURE_SECTION << SECTION_SHIFT)
#define IsSecureVa(va)      (SECURE_SECTION == ((DWORD) (va) >> SECTION_SHIFT))

#define ZeroPtrABS(P) \
	((((DWORD)(P) & 0x80000000) && !IsSecureVa(P)) ? \
		(DWORD)(P) : ((DWORD)(P) & ((1<<SECTION_SHIFT)-1)))

#define ZeroPtr(P)  \
	(((DWORD)(P) < (2<<SECTION_SHIFT))? \
		(DWORD) (P) : ZeroPtrABS(P))

#define MapPtrWithBits(Ptr, Bits) \
	(!(Ptr) || ((DWORD)(Ptr)>>SECTION_SHIFT) ? \
		(LPVOID)(Ptr) : (LPVOID)((DWORD)(Ptr)|(Bits)))
