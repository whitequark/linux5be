#if !defined(XKDBG_H)
#define XKDBG_H

int
KdbgDumpModuleObject(struct o32_lite* o32ptr, BYTE objType);

void
KdbgDumpImports(struct ImpHdr* impHdrPtr);

void
KdbgDumpExportHeader(DWORD BasePtr, struct ExpHdr* expHdrPtr);

void
KdbgDumpExportFunctions(DWORD BasePtr, struct ExpHdr* expHdrPtr);

void
KdbgDumpExports(DWORD BasePtr, struct ExpHdr* expHdrPtr);

void
KdbgDumpExeExports(PPROCESS pProc);

void
KdbgDumpDllExports(PMODULE pMod);

void
KdbgDumpExceptionTable(PRUNTIME_FUNCTION rtChain, LONG size);


#endif  // !defined(XKDBG_H)
