#include <windows.h>
#include <io.h>
#include <fcntl.h>

#include "cekernel.h"

#define MAKEPTR( cast, ptr, addValue ) (cast)( (DWORD)(ptr) + (DWORD)(addValue))
#define MAKERAMPTR(ptr) MAKEPTR(DWORD*, m_pRamBase, ptr )

CEKDataClass::CEKDataClass(char *pszMemFileName)
: m_hFileMapping(INVALID_HANDLE_VALUE), 
  m_dwFileHandle((LONG)-1),
  m_pRamBase(0)
{

#if !defined(UNDER_CE)

	if (pszMemFileName != NULL)
	{
		m_dwFileHandle = _get_osfhandle(_open("pszMemFileName",_O_RDONLY));
		if ( m_dwFileHandle == (LONG)-1 ) return;

		m_hFileMapping = CreateFileMappingA((HANDLE)m_dwFileHandle,
									  0,
							          PAGE_READONLY,
							          0,
							          0,
							          "pszMemFileName");
		if ( m_hFileMapping = INVALID_HANDLE_VALUE ) 
		{
			_close(m_dwFileHandle);
			m_dwFileHandle = (LONG)-1;
			return;
		}
		
		m_pRamBase = (DWORD) MapViewOfFile(m_hFileMapping,FILE_MAP_READ,0,0,0);
		if (m_pRamBase == NULL)
		{
			_close(m_dwFileHandle);
			m_dwFileHandle = (LONG)-1;
			CloseHandle(m_hFileMapping);
			m_hFileMapping = INVALID_HANDLE_VALUE;
		}
	}

#else

	m_dwRamBase = (DWORD)KSEG0_BASE;   /* base of cached kernel physical   */

#endif

	m_pKPage = (PKPAGE) MAKERAMPTR(KernelPageAbsolute);

	return;
}

DWORD
CEKDataClass::Virt2Phys(DWORD addr)
{
	PKDATASTRUCT	kData;
	PSECTION		sectionPtr; 
	PMEMBLOCK		blockPtr;
	DWORD			pageFramePtr;
	DWORD			section, block, page;
	DWORD			physAddr;

	if ( addr >= KSEG0_BASE ) 
	{
		/* 
		 * addr is a physical kseg reference so it mapped directly to RAM and
		 * no conversion is needed. addr[30:0] map directly to a physical address
		*/
		DWORD ret = addr & (MAX_RAM_SIZE-1);
		return (ret);
	}

	section =  addr >> VA_SECTION;
	block	= (addr >> VA_BLOCK) & BLOCK_MASK;
	page	= (addr >> VA_PAGE) & PAGE_MASK;

	// get pointer kerel data structure
	kData = &( ( (PKPAGE) MAKERAMPTR(KernelPageAbsolute) )->KData );

	// get pointer to section
	sectionPtr = (PSECTION) Virt2Phys((DWORD) kData->SectionTable[section]);

	// get pointer to block
	blockPtr = (PMEMBLOCK) Virt2Phys( (DWORD) ( (MAKERAMPTR(sectionPtr))[block] ) );

	// get pointer to page frame
	pageFramePtr = ((PMEMBLOCK)MAKERAMPTR(blockPtr))->aPages[page];  

	// merge PFN with address offset to get physical address
	physAddr = ((pageFramePtr << PFN_SHIFT) & PFN_MASK) | (addr & 0xFFF);

	return physAddr;
}

CEKDataClass::~CEKDataClass(void)
{
	return;
}
