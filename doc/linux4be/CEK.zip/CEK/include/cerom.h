
/*
 * Module Table of Contents - follows ROMHDR in image
*/
typedef struct TOCentry				/* MODULE BIB section structure */
{									/* ---------------------------- */
    ULONG		dwFileAttributes;	
    FILETIME	ftTime;
    ULONG		nFileSize;
    LPSTR		lpszFileName;
    DWORD		ulE32Offset;		/* Offset to E32 structure      */
    DWORD		ulO32Offset;		/* Offset to O32 structure      */
    DWORD		ulLoadOffset;		/* MODULE load buffer offset    */
} TOCentry, *LPTOCentry;
