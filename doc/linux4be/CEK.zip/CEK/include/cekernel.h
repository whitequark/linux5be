
#include "cek.h"

class CEKDataClass
{
public:
	CEKDataClass(char *pszMemFileName = NULL);
	~CEKDataClass();

	DWORD	Virt2Phys(DWORD addr);

private:
	LONG	m_dwFileHandle;
	HANDLE	m_hFileMapping;
	
	DWORD	m_pRamBase;
	PKPAGE	m_pKPage;

}CEKData;