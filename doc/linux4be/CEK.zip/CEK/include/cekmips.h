								/*        indices for for KInfoTable array        */
								/* ---------------------------------------------- */
#define KINX_PROCARRAY  0		/* address of process array						  */
#define KINX_PAGESIZE   1		/* system page size								  */
#define KINX_PFN_SHIFT  2		/* shift for page # in PTE						  */
#define KINX_PFN_MASK   3		/* mask for page # in PTE						  */
#define KINX_PAGEFREE   4		/* # of free physical pages						  */
#define KINX_SYSPAGES   5		/* # of pages used by kernel					  */
#define KINX_KHEAP      6		/* ptr to kernel heap array						  */
#define KINX_SECTIONS   7		/* ptr to SectionTable array					  */
#define KINX_MEMINFO    8		/* ptr to system MemoryInfo struct				  */
#define KINX_MODULES    9		/* ptr to module list							  */
#define KINX_DLL_LOW   10		/* lower bound of DLL shared space				  */
#define KINX_NUMPAGES  11		/* total # of RAM pages							  */
#define KINX_PTOC      12		/* ptr to ROM table of contents					  */
#define KINX_KDATA_ADDR	13		/* kernel mode version of KData					  */
#define KINX_GWESHEAPINFO 14	/* Current amount of gwes heap in use			  */
#define KINX_TIMEZONEBIAS 15	/* Fast timezone bias info						  */
#define KINX_PENDEVENTS 16		/* bit mask for pending interrupt events		  */
#define KINX_KERNRESERVE 17		/* number of kernel reserved pages				  */
#define KINX_API_MASK 18 		/* bit mask for registered api sets				  */
#define KINX_NLS_OCP 19			/* Current OEM code page						  */
#define KINX_NLS_ACP 20			/* Current ANSI code page						  */
#define KINX_NLS_LOC 21			/* Current NLS locale							  */
#define KINX_HEAP_WASTE 22		/* Kernel heap wasted space						  */
#define KINX_DEBUGGER 23		/* For use by debugger for protocol communication */
#define KINX_APISETS 24			/* APIset pointers								  */

typedef struct KDataStruct      /* The Kernel Data Structure                          */
{                               /* -------------------------------------------------- */
	LPDWORD		lpvTls;			/* 0x000 Current thread local storage pointer         */
    HANDLE		SystemHandles[NUM_SYS_HANDLES]; /* 0x004 If this moves, change kapi.h */
    char		ReschedFlag;       /* 0x084 reschedule flag                           */
    char		KNest;          /* 0x085 kernel exception nesting                     */
    char		pad;			/* 0x086 alignment padding                            */
    char		BPowerOff;      /* 0x087 - power off flag                             */
	ULONG		SaveT0;			/* 0x088 kernel temp saved T0                         */
	ULONG		SaveK1;			/* 0x08c kernel temp saved K1                         */
	ULONG		BasePSR;		/* 0x090                                              */
    ULONG		CurMSec;        /* 0x094 # of milliseconds since boot                 */
    ULONG		DiffMSec;       /* 0x098 # of mSec since last TimerCallBack           */
	ACCESSKEY	CurAKey;		/* 0x09c current access key                           */
	PFNKDBG		DbgEntry;       /* 0x0a0 kernel debugger entry point                  */
	DWORD		FalseInt;       /* 0x0a4 false interrupt service routine              */
	DWORD		ISRTable[6];	/* 0x0a8 first level intr service routines            */	
	PSECTION	SectionTable[64];	/* 0x0c0 section table for virutal memory         */
	LPEVENT		IntrEvents[SYSINTR_MAX_DEVICES];	/* 0x1c0						  */
	LPVOID		IntrData[SYSINTR_MAX_DEVICES];		/* 0x240						  */
	PTHREAD		CurThdPtr;		/* 0x2c0: ptr to current THREAD struct				  */
	PPROCESS	CurPrcPtr;		/* 0x2c4 ptr to current PROCESS struct                */
	ULONG		HandleBase;		/* 0x2c8: handle table base address                   */
	ULONG		PtrAPIRet;		/* 0x2cc direct API return address for kernel mode    */
	DWORD		dwKCRes;		/* 0x2d0                                              */
	DWORD		dwInDebugger;	/* 0x2d4 !0 if in debugger                            */
	BYTE		bPadding[32];	/* 0x2d8                                              */
    PTHREAD		g_CurFPUOwner;	/* 0x2f8 Current FPU owner thread                     */
    LONG		aPad;        	/* 0x2fc - padding                                    */
	DWORD		KInfoTable[32]; /* 0x300 - misc. kernel info                          */
								/* 0x340 - end                                        */
} KDATASTRUCT, *PKDATASTRUCT;


#define KSTACK_SIZE		2016
#define KTEMP_SIZE		(8*sizeof(ULONG))

typedef struct KPage
{
	char		KStack[KSTACK_SIZE];				/* 0x0000 */
	ULONG		KTemp[KTEMP_SIZE/sizeof(ULONG)];	/* 0x07E0 */
	KDATASTRUCT KData;								/* 0x0800 */
	ULONG		PendEvents;							/* 0x0840 */
	LONG		extraInfo[27];						/* 0x0B44 */
	ULONG		SaveK0;								/* 0x0BB0 */
} KPAGE, *PKPAGE;									/* 0x0BB4 */

#define KPAGE_PHYS  0x00001000

#define KernelDataAbsolute	((PKDATASTRUCT)KPAGE_PHYS + 0x800)
#define KernelPageAbsolute	((PKPAGE)KPAGE_PHYS)
//PKDATASTRUCT	KernelDataAbsolute = ((KDATASTRUCT*)KPAGE_PHYS + 0x800);
//PKPAGE			KernelPageAbsolute = ( (PKPAGE)KPAGE_PHYS );
