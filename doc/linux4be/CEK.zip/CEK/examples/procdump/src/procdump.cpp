#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include <tchar.h>

#include "../../../include/xkernel.h"
#include "../../../include/xkdbg.h"


int main() 
{
	PKPAGE		pKPage;
	PPROCESS	pProcArray;
	PPROCESS	pProcCurrent;

	wchar_t*	lpszProcName;
	wchar_t*	pcmdline;
	LPName*		pStdNames;
	HANDLE		hProc;
	DWORD		pfnEH;
	LPPROXY		pProxList;
	PTHREAD		pMainTh;
	PTHREAD     pTh;
	HANDLE		hDbgrThrd;
	LPDBGPARAM  ZonePtr;
	PMODULE		pmodResource;
	LPVOID      BasePtr;
	e32_lite*   e32_ptr;
	o32_lite*	o32_ptr;
	openexe_t*  oe_ptr;
	o32_lite*	optr;
	DWORD		realaddr;

	int index, index2;
	
	pKPage = KernelInitData("./../../MemDump4.bin");
	if (pKPage == NULL) 
	{
		printf("Error initializing Kerenl Data\n");
		return -1;		// error initializing access to kernel data page
	}

	pProcArray = KernelGetProcessArray(pKPage);

	printf("ProcArray = %08X\n",
		ZeroRamAddr(pProcArray));
	
	index=0; //process created by device.exe

for(index=0; index<MAX_PROCESSES; index++)
{

	pProcCurrent = &pProcArray[index];

	if (pProcCurrent->lpszProcName == NULL) continue;


	printf("ProcArray[%i] = %08X\n",
		index,
		ZeroRamAddr(pProcCurrent));

	lpszProcName = (wchar_t*) KernelVirt2Ram((DWORD)pProcCurrent->lpszProcName);
	
	wprintf(L"  lpszProcName:  %08X (%s)    dwVMBase:       %08X\n", 
		ZeroRamAddr(lpszProcName), 
		lpszProcName,
		pProcCurrent->dwVMBase);

	pcmdline = (wchar_t*) KernelVirt2Ram((DWORD)pProcCurrent->pcmdline);
	wprintf(L"  pcmdline:      %08X (%s)\n", 
		ZeroRamAddr(pcmdline), 
		pcmdline);

	pStdNames = (LPName*) KernelVirt2Phys((DWORD)pProcCurrent->pStdNames);
	printf("  pStdNames:     %08X (%08X)      procnum:        %02X\n",
		pProcCurrent->pStdNames, 
		pStdNames,
		pProcCurrent->procnum);

	hProc = (HANDLE) KernelVirt2Phys((DWORD)pProcCurrent->hProc);
	pfnEH = (DWORD) KernelVirt2Phys((DWORD)pProcCurrent->pfnEH);
	printf("  hProc:         %08X (%08X)      pfnEH:          %08X (%08X)\n",
		pProcCurrent->hProc,
		hProc,
		pProcCurrent->pfnEH,
		pfnEH);

	pProxList = (LPPROXY) KernelVirt2Phys((DWORD)pProcCurrent->pProxList);
	printf("  pProxList:     %08X (%08X)\n",
		pProcCurrent->pProxList,
		pProxList);

	pMainTh = (PTHREAD) KernelVirt2Phys((DWORD)pProcCurrent->pMainTh);
	pTh = (PTHREAD) KernelVirt2Phys((DWORD)pProcCurrent->pTh);
	printf("  pMainTh:       %08X (%08X)      pTh:            %08X (%08X)\n",
		pProcCurrent->pMainTh,
		pMainTh,
		pProcCurrent->pTh,
		pTh);

	printf("  tlsLowUsed:    %08X                 tlsHighUsed:    %08X\n",
		pProcCurrent->tlsLowUsed,
		pProcCurrent->tlsHighUsed);

	printf("  aky:           %08X                 dwDyingThreads: %i\n",
		pProcCurrent->aky,
		pProcCurrent->dwDyingThreads);

	hDbgrThrd = (HANDLE) KernelVirt2Phys((DWORD)pProcCurrent->hDbgrThrd);
	ZonePtr = (LPDBGPARAM) KernelVirt2Phys((DWORD)pProcCurrent->ZonePtr);
	printf("  hDbgrThrd:     %08X (%08X)      ZonePtr:        %08X (%08X)\n",
		pProcCurrent->hDbgrThrd,
		hDbgrThrd,
		pProcCurrent->ZonePtr,
		ZonePtr);

	printf("  DbgActive:     %02X                       bChainDebug:    %02X\n",
		pProcCurrent->DbgActive,
		pProcCurrent->bChainDebug);

	pmodResource = (PMODULE) KernelVirt2Phys((DWORD)pProcCurrent->pmodResource);
	printf("  pmodResource:  %08X (%08X)\n",
		pProcCurrent->pmodResource,
		pmodResource);

	BasePtr = (LPVOID) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr);
	printf("  BasePtr:       %08X (%08X)      bTrustLevel:    %02X\n",
		pProcCurrent->BasePtr,
		BasePtr,
		pProcCurrent->bTrustLevel);

	e32_ptr = (e32_lite*) ZeroRamAddr(&pProcCurrent->e32);
	o32_ptr = (o32_lite*) KernelVirt2Phys((DWORD)pProcCurrent->o32_ptr);
	printf("  e32_ptr:       %08X                 o32_ptr:        %08X (%08X)\n",
		e32_ptr,
		pProcCurrent->o32_ptr,
		o32_ptr);

	oe_ptr = (openexe_t*) ZeroRamAddr(&pProcCurrent->oe);
	printf("  oe_ptr:        %08X\n", oe_ptr);

	printf(" e32_unit[EXP]  rva = %08X (%08X)    size = %08X  - EXPORT TABLE\n",
		pProcCurrent->e32.e32_unit[EXP].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[EXP].rva),
		pProcCurrent->e32.e32_unit[EXP].size);

//	KdbgDumpExeExports(pProcCurrent);

	printf(" e32_unit[IMP]  rva = %08X (%08X)    size = %08X  - IMPORT TABLE\n", 
		pProcCurrent->e32.e32_unit[IMP].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[IMP].rva),
		pProcCurrent->e32.e32_unit[IMP].size);

//	KdbgDumpImports((struct ImpHdr*) KernelVirt2Ram((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[IMP].rva));

	printf(" e32_unit[RES]  rva = %08X (%08X)    size = %08X  - RESOURCE TABLE\n", 
		pProcCurrent->e32.e32_unit[RES].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[RES].rva),
		pProcCurrent->e32.e32_unit[RES].size);
	
	printf(" e32_unit[EXC]  rva = %08X (%08X)    size = %08X  - EXCEPTION TABLE\n", 
		pProcCurrent->e32.e32_unit[EXC].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[EXC].rva),
		pProcCurrent->e32.e32_unit[EXC].size);
	
//	KdbgDumpExceptionTable(
//		(PRUNTIME_FUNCTION) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[EXC].rva),
//		pModule->e32.e32_unit[EXC].size);

	printf(" e32_unit[SEC]  rva = %08X (%08X)    size = %08X  - SECURITY TABLE\n", 
		pProcCurrent->e32.e32_unit[SEC].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[SEC].rva),
		pProcCurrent->e32.e32_unit[SEC].size);
	
	printf(" e32_unit[FIX]  rva = %08X (%08X)    size = %08X  - FIXUP TABLE\n", 
		pProcCurrent->e32.e32_unit[FIX].rva,
		(DWORD) KernelVirt2Phys((DWORD)pProcCurrent->BasePtr + pProcCurrent->e32.e32_unit[FIX].rva),
		pProcCurrent->e32.e32_unit[FIX].size);

	printf(" pagemode = %08X\n", pProcCurrent->oe.pagemode);
	printf(" filetype = %08X\n", pProcCurrent->oe.filetype);
	printf(" objcnt = %i\n", pProcCurrent->e32.e32_objcnt);

	for(index2 = 0; index2 < pProcCurrent->e32.e32_objcnt; index2++) 
	{
//		KdbgDumpModuleObject(&pProcCurrent->o32_ptr[index],index);

		optr = (struct o32_lite *) KernelVirt2Ram((DWORD)&pProcCurrent->o32_ptr[index2]);
		realaddr = (DWORD) KernelVirt2Ram(optr->o32_realaddr);
		
		// dump the raw data
		if( (realaddr - KernelRamBase) == 0 )
		{
			printf("\nObject not in RAM\n\n");
			continue;
		}

		printf("\nObject at %08X\n",realaddr);

	}
	printf("------------------------------------------------------------\n");

}
	return 0;
}