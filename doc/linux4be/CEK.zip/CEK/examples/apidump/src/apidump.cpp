/* from PUBLIC\COMMON\OAK\INC\PSYSCALL.H */
#define FIRST_METHOD 	0xFFFFFC02
#define APICALL_SCALE	4
#define NUM_SYS_HANDLES  32
#define HANDLE_SHIFT 	8
#define METHOD_MASK 0x00FF
#define HANDLE_MASK 0x003F

#define METHOD_CALL(mid)        (FIRST_METHOD + (mid)*APICALL_SCALE)
#define IMPLICIT_CALL(hid, mid) (FIRST_METHOD - ((hid)<<HANDLE_SHIFT | (mid))*APICALL_SCALE)

#include <windows.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "../../../include/xkernel.h"

CHAR* 
_id2String(CHAR* id,CHAR* buffer)
{
	// buffer should be a preallocated array of at least 5 bytes
	memcpy(buffer,id,4);

	if(buffer[3] == '\0') buffer[3] = ' '; //for output justification

	buffer[4] = '\0';
	return buffer;
}

void
_printAPIDispatchType(int disp)
{
	switch(disp)
	{
	case DISPATCH_KERNEL:
		printf("%-19s","DISPATCH_KERNEL");
		break;
	case DISPATCH_I_KERNEL:
		printf("%-19s","DISPATCH_I_KERNEL");
		break;
	case DISPATCH_KERNEL_PSL:
		printf("%-19s","DISPATCH_KERNEL_PSL");
		break;
	case DISPATCH_I_KPSL:
		printf("%-19s","DISPATCH_I_KPSL");
		break;
	case DISPATCH_PSL:
		printf("%-19s","DISPATCH_PSL");
		break;
	case DISPATCH_I_PSL:
		printf("%-19s","DISPATCH_I_PSL");
		break;
	default:
		printf("%-19s","DISPATCH_UNKNOWN");
		break;
	}
}

void
_printAPIHandleType(int type)
{
	switch(type)
	{
	case SH_WIN32:
		printf("%-21s","SH_WIN32");
		break;
	case SH_CURTHREAD:
		printf("%-21s","SH_CURTHREAD");
		break;
	case SH_CURPROC:
		printf("%-21s","SH_CURPROC");
		break;
	case SH_KWIN32:
		printf("%-21s","SH_KWIN32");
		break;
	case HT_EVENT:
		printf("%-21s","HT_EVENT");
		break;
	case HT_MUTEX:
		printf("%-21s","HT_MUTEX");
		break;
	case HT_APISET:
		printf("%-21s","HT_APISET");
		break;
	case HT_FILE:
		printf("%-21s","HT_FILE");
		break;
	case HT_FIND:
		printf("%-21s","HT_FIND");
		break;
	case HT_DBFILE:
		printf("%-21s","HT_DBFILE");
		break;
	case HT_DBFIND:
		printf("%-21s","HT_DBFIND");
		break;
	case HT_SOCKET:
		printf("%-21s","HT_SOCKET");
		break;
	case HT_INTERFACE:
		printf("%-21s","HT_INTERFACE");
		break;
	case HT_SEMAPHORE:
		printf("%-21s","HT_SEMAPHORE");
		break;
	case HT_FSMAP:
		printf("%-21s","HT_FSMAP");
		break;
	case HT_WNETENUM:
		printf("%-21s","HT_WNETENUM");
		break;
	case SH_LAST_NOTIFY:
		printf("%-21s","SH_LAST_NOTIFY/SH_GDI");
		break;
	case SH_WMGR:
		printf("%-21s","SH_WMGR");
		break;
	case SH_WNET:
		printf("%-21s","SH_WNET");
		break;
	case SH_COMM:
		printf("%-21s","SH_COMM");
		break;
	case SH_FILESYS_APIS:
		printf("%-21s","SH_FILESYS_APIS");
		break;
	case SH_SHELL:
		printf("%-21s","SH_SHELL");
		break;
	case SH_DEVMGR_APIS:
		printf("%-21s","SH_DEVMGR_APIS");
		break;
	case SH_TAPI:
		printf("%-21s","SH_TAPI");
		break;
	case SH_PATCHER:
		printf("%-21s","SH_PATCHER");
		break;
	default:
		printf("%-21s","HANDLE_UNKNOWN");
		break;
	}
}

int main(void)
{
	PKPAGE pKPage;
	CHAR* ramFileName = "./../../MemDump4.bin";
	int index, index2;

	CINFO**		SystemAPISets; //[NUM_SYSTEM_SETS];
	CINFO*		cInfoPtr;
	CHAR		cInfoID[4+1];
	PPROCESS   	pServer;
	wchar_t*	procName;
	wchar_t*	nullString = L"";
	PFNVOID*	ppfnMethods;
	PFNVOID		pfnMethod;
	DWORD*		pdwSig;
	DWORD		dwSig;
	USHORT      cMethods;
	DWORD		dwVMBase;

	pKPage = KernelInitData(ramFileName);

	if (pKPage == NULL)
	{
		printf("Error initializing Kernel Data Space with RamFile %s\n",
			ramFileName);
		return -1;		// error initializing access to kernel data page
	}

	SystemAPISets = (CINFO **) KernelVirt2Ram((DWORD)pKPage->KData.KInfoTable[KINX_APISETS]);

	printf("KInfoTable[KINX_APISETS]: %08X (%08X)\n",
		pKPage->KData.KInfoTable[KINX_APISETS],
		ZeroRamAddr(SystemAPISets));

	printf("---------------------------------------------\n");

	for (index = 0; index<NUM_SYSTEM_SETS; index++)
	{
		cInfoPtr = (CINFO *) KernelVirt2Ram((DWORD) SystemAPISets[index]);

		printf("API Set %02X: %08X (%08X)\n",
			index,
			SystemAPISets[index],
			ZeroRamAddr(cInfoPtr) );
		
		if(SystemAPISets[index])
		{
			printf("  acName: %s    disp: ",
				_id2String(cInfoPtr->acName,cInfoID) );

			_printAPIDispatchType(cInfoPtr->disp);

			printf("    type: ");

			_printAPIHandleType(cInfoPtr->type);

			pServer = (PPROCESS) KernelVirt2Ram((DWORD)cInfoPtr->pServer);

			if(ZeroRamAddr(pServer))
				procName = (wchar_t*) KernelVirt2Ram((DWORD)pServer->lpszProcName);
			else
				procName = nullString;

			wprintf(L"\n  cMethods: %03i    pServer: %-15s %08X (%08X)\n",
				cInfoPtr->cMethods,
				procName,
				cInfoPtr->pServer,
				ZeroRamAddr(pServer));
			
			if(cInfoPtr->pServer)
				dwVMBase = (DWORD) pServer->dwVMBase;
			else
				dwVMBase = 0; // in Kernel Address Space

			printf("                  dwVMBase: %08X\n",dwVMBase);
			ppfnMethods = (PFNVOID*) KernelVirt2Ram(dwVMBase + (DWORD)cInfoPtr->ppfnMethods);
			pdwSig = (DWORD*) KernelVirt2Ram(dwVMBase + (DWORD)cInfoPtr->pdwSig);

			printf("  ppfnMethods: %08X (%08X)    pdwSig: %08X (%08X)\n",
				cInfoPtr->ppfnMethods,
				ZeroRamAddr(ppfnMethods),
				cInfoPtr->pdwSig,
				ZeroRamAddr(pdwSig));

			for(cMethods = cInfoPtr->cMethods, index2 = 0; index2 < cMethods; index2++)
			{
				pfnMethod = (PFNVOID) KernelVirt2Ram(dwVMBase + (DWORD)ppfnMethods[index2]);
				
				if(ZeroRamAddr(pfnMethod))
				{
					printf("    pfnMethod%04X: %08X (%08X)",
						index2,
						ppfnMethods[index2],
						ZeroRamAddr(pfnMethod) );

					dwSig = 0;
					if(ZeroRamAddr(pdwSig) != 0)
					{
						dwSig = pdwSig[index2];
					}

					printf("    dwSig: %08X\n",	dwSig);
				}
			}
		}
		printf("\n");
	}

	return 0;
}