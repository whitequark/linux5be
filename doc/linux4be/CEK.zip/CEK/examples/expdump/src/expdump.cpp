#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include <tchar.h>

#include "../../../include/xkernel.h"
#include "../../../include/xkdbg.h"

int main() 
{
	PKPAGE	pKPage;
	PMODULE pModule;
	struct ExpHdr* expHdrPtr;

	pKPage = KernelInitData("./../../MemDump4.bin");
	if (pKPage == NULL) return -1;		// error initializing access to kernel data page

	pModule = KernelFindModuleFirst( pKPage );

	if (pModule == NULL)
	{
		printf("Error: Error in KernelFindModuleFirst.\n");
		return -1;
	}

	while(pModule)
	{
		wprintf(L"%s\n",
			(WCHAR*)MAKERAMPTR(KernelVirt2Phys((DWORD)pModule->name)));
	
		expHdrPtr = (struct ExpHdr*) MAKERAMPTR(KernelVirt2Phys((DWORD)pModule->BasePtr + (DWORD)pModule->e32.e32_unit[EXP].rva));

		if ( ZeroRamAddr(expHdrPtr) == 0 ) 
		{
			// module does not export any symbols, so go check the next one
			pModule = KernelFindModuleNext( pModule );
			continue; // invalid expHdrPtr
		}

		KdbgDumpExportFunctions((DWORD)pModule->BasePtr, expHdrPtr);

		pModule = KernelFindModuleNext( pModule );
	}

	return 0;
}