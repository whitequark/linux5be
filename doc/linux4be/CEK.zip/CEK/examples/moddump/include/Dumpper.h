#if !defined(DUMPPER_H)
#define DUMPPER_H

int
DumpRam( DWORD phyStartAddress, DWORD phyEndAddress, int cbType);



#define DUMP_CALLBACK_BEFORE	0x01
#define DUMP_CALLBACK_DURING	0x02
#define DUMP_CALLBACK_AFTER		0x04
#define DUMP_CALLBACK_ALL		0x07

typedef void (*DumpCallBack)(void);

void
DumpSetCallback(DumpCallBack callBack, int cbType);

void
DumpSetFileNameAndPath(TCHAR* dumpFileName);

#define DUMP_MODE_OVERWRITE		0x00
#define DUMP_MODE_APPEND		0x01

int 
DumpBuffer (char* fileName, BYTE* buffer, ULONG count, int mode = 0);

BOOL
dumpFunction(DWORD vAddr);

#endif  /* !defined(DUMPPER_H) */