
#include <windows.h>

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <io.h>
#include <tchar.h>

#include "../../../include/xkernel.h"
#include "../../../include/xkdbg.h"

#include "../include/Dumpper.h"

inline void
myDumpCallBack(void)
{
	printf("*");
}

int main() 
{

	PMODULE pModule;
	PKPAGE	pKPage;
	DWORD	self, next;
	DWORD	BasePtr, startip, pmodResource;
	DWORD	calledfunc, ZonePtr;
	DWORD	oe, e32, o32_ptr;
	DWORD	adjBaseAdr,BaseDiff;
	
	PROCESS* processPtr, *process0Ptr;

	struct o32_lite *optr;
	int loop;
	int processOwner=-1;

	DWORD realaddr;

	DWORD anyAddr;
	DWORD phyAnyAddr, phy0AnyAddr;
	
	DumpSetCallback(myDumpCallBack, DUMP_CALLBACK_DURING);

	pKPage = KernelInitData("./../../MemDump4.bin");
	//pKPage = KernelInitData("MemDump_touch_loaded.bin");
	
	if (pKPage == NULL) return -1;		// error initializing access to kernel data page

	pModule = KernelFindModule( pKPage, "coredll.dll" );
	//pModule = KernelFindModule( pKPage, "serial.dll" );
	//pModule = KernelFindModule( pKPage, "mydll_ce.dll" );
	//pModule = KernelFindModule( pKPage, "cso.dll" );
	if (pModule == NULL)
	{
		printf("Error: Could not find requested module.\n");
		exit(-1);
	}

	anyAddr = 0x0194a054;
	phyAnyAddr = (DWORD) KernelVirt2Phys((DWORD)anyAddr);
	phy0AnyAddr = (DWORD) KernelVirt2Phys((DWORD)MapPtrInModule(anyAddr,pModule));

	wprintf(L"name: %08X (%s)     $%08X  PHY=$%08X(V) / $%08X(Z)\n",
		(DWORD) KernelVirt2Ram((DWORD)pModule->name),
		(WCHAR*) KernelVirt2Ram((DWORD)pModule->name),
		anyAddr,
		phyAnyAddr,
		phy0AnyAddr);
	
	printf("KernelRamBase = %08X\n",KernelRamBase);

	self = (DWORD) KernelVirt2Ram((DWORD)pModule->self);
	next = (DWORD) KernelVirt2Ram((DWORD)pModule->next);

	printf("self: %08X (%08X)       next: %08X (%08X)\n",
		pModule->self, self,
		pModule->next, next);

	BasePtr = (DWORD) KernelVirt2Ram((DWORD)pModule->BasePtr);
	startip = (DWORD) KernelVirt2Ram((DWORD)MapPtrInModule(pModule->startip,pModule));

	printf("BasePtr: %08X (%08X)    startip: %08X (%08X)\n",
		pModule->BasePtr, BasePtr,
		pModule->startip, startip);

	printf("e32.vsize: %08X    e32.vbase: %08X (%08X)\n",
		pModule->e32.e32_vsize,
		pModule->e32.e32_vbase,
		(DWORD) KernelVirt2Ram((DWORD)pModule->e32.e32_vbase) );

	pmodResource = (DWORD) KernelVirt2Ram((DWORD)pModule->pmodResource);

	printf("pmodResource: %08X (%08X)\n",
		pModule->pmodResource, pmodResource);

	calledfunc = (DWORD) KernelVirt2Ram((DWORD)pModule->calledfunc);
	
	printf("inuse: %08X                 calledfunc: %08X (%08X)\n",
		pModule->inuse,
		pModule->calledfunc, calledfunc);

	printf("refcnt[]: ");
	for(loop = 0; loop < MAX_PROCESSES; loop++)
	{
		printf("%i-",pModule->refcnt[loop]);
		if ( (pModule->refcnt[loop] > 0) && (processOwner == -1) )
			processOwner = loop;
	}
	printf("\n");

	processPtr	= &(KernelGetProcessArray(pKPage))[processOwner];
//	processPtr = KernelGetProcess(processOwner);
	process0Ptr	= &(KernelGetProcessArray(pKPage))[0];
//	process0Ptr = KernelGetProcess(0);

	printf("processOwner's  processPtr %08X, procnum:%02i, dwVMBase: %08X\n",
		processPtr, processPtr->procnum, processPtr->dwVMBase);

	printf("process0's      processPtr %08X, procnum:%02i, dwVMBase: %08X\n",
		process0Ptr, process0Ptr->procnum, process0Ptr->dwVMBase);

	BaseDiff = processPtr->dwVMBase - process0Ptr->dwVMBase;
	adjBaseAdr = (DWORD) KernelVirt2Ram((DWORD)processPtr->dwVMBase);
	
	printf("Module adjBaseAdr: %08X (%08X) (%08X)\n",
		adjBaseAdr,
		KernelVirt2Phys( (DWORD) adjBaseAdr ),
		(DWORD) KernelVirt2Ram( (DWORD) adjBaseAdr ) );

	ZonePtr = (DWORD) KernelVirt2Ram((DWORD)pModule->ZonePtr);

	printf("DbgFlags: %08X              ZonePtr: %08X (%08X)\n",
		pModule->DbgFlags,
		pModule->ZonePtr, ZonePtr);

	oe = (DWORD) KernelVirt2Ram((DWORD)&pModule->oe);
	e32 = (DWORD) KernelVirt2Ram((DWORD)&pModule->e32);

	printf("&oe: %08X (%08X)        &e32: %08X (%08X)\n",
		&pModule->oe,  oe,
		&pModule->e32, e32);		

	o32_ptr = (DWORD) KernelVirt2Ram((DWORD)pModule->o32_ptr);
		
	printf("o32_ptr: %08X (%08X)\n",
		pModule->o32_ptr, o32_ptr);

	printf("breadcrumb: %08X            bTrustLevel: %08X\n",
		pModule->breadcrumb, pModule->bTrustLevel);

	printf("wFlags: %08X                dwNoNotify: %08X\n",
		pModule->wFlags, pModule->dwNoNotify);

	printf("------------------------------------------------------------\n");

	printf(" e32_unit[EXP]  rva = %08X (%08X)    size = %08X  - EXPORT TABLE\n",
		pModule->e32.e32_unit[EXP].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[EXP].rva),
		pModule->e32.e32_unit[EXP].size);
	
	KdbgDumpDllExports(pModule);

	printf(" e32_unit[IMP]  rva = %08X (%08X)    size = %08X  - IMPORT TABLE\n", 
		pModule->e32.e32_unit[IMP].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[IMP].rva),
		pModule->e32.e32_unit[IMP].size);
	
	KdbgDumpImports((struct ImpHdr*) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[IMP].rva));

	printf(" e32_unit[RES]  rva = %08X (%08X)    size = %08X  - RESOURCE TABLE\n", 
		pModule->e32.e32_unit[RES].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[RES].rva),
		pModule->e32.e32_unit[RES].size);
	
	printf(" e32_unit[EXC]  rva = %08X (%08X)    size = %08X  - EXCEPTION TABLE\n", 
		pModule->e32.e32_unit[EXC].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[EXC].rva),
		pModule->e32.e32_unit[EXC].size);
	
//	KdbgDumpExceptionTable(
//		(PRUNTIME_FUNCTION) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[EXC].rva),
//		pModule->e32.e32_unit[EXC].size);

	printf(" e32_unit[SEC]  rva = %08X (%08X)    size = %08X  - SECURITY TABLE\n", 
		pModule->e32.e32_unit[SEC].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[SEC].rva),
		pModule->e32.e32_unit[SEC].size);
	
	printf(" e32_unit[FIX]  rva = %08X (%08X)    size = %08X  - FIXUP TABLE\n", 
		pModule->e32.e32_unit[FIX].rva,
		(DWORD) KernelVirt2Ram(pModule->BasePtr + pModule->e32.e32_unit[FIX].rva),
		pModule->e32.e32_unit[FIX].size);
	
	printf(" pagemode = %08X\n", pModule->oe.pagemode);
	printf(" filetype = %08X\n", pModule->oe.filetype);
	printf(" objcnt = %i\n", pModule->e32.e32_objcnt);

	for(loop = 0; loop < pModule->e32.e32_objcnt; loop++) 
	{
		char objName[10];

		KdbgDumpModuleObject(&pModule->o32_ptr[loop],loop);

		optr = (struct o32_lite *) KernelVirt2Ram((DWORD)&pModule->o32_ptr[loop]);
		realaddr = (DWORD) KernelVirt2Ram(optr->o32_realaddr);
		
		// dump the raw data
		if( (realaddr - KernelRamBase) == 0 )
		{
			printf("\nCan't dump, Object not in RAM\n\n");
			continue;
		}

		printf("\nDumping Object at %08X",realaddr);
		sprintf(objName,"object%i.bin",loop);
		DumpBuffer (objName, (BYTE*) realaddr, optr->o32_vsize, DUMP_MODE_OVERWRITE);
		printf("\n\n");

	}

	return 0;
}

// winnt.h