#define  PAGE_SIZE          4096
#define  RAM_BASE_UNCACHED  0x80000000
#define  RAM_BASE_CACHED    0xA0000000
#define  RAM_MAX            0x00FFFFFF
#define  RAM_SIZE           (RAM_MAX+1)

#define  DUMP_FILE_NAME     "ModDump.bin"

#include <windows.h>
#include <tchar.h>
#include <stdio.h>

#include "../include/Dumpper.h"
#include "../../../include/xcoredll.h"

#include "../../../include/xkernel.h"
#include "../../../utils/MipsDism/include/mips.h"

inline void
DumpCB_Before(void)
{
	return;	// do nothing
}

inline void
DumpCB_During(void)
{
	return;	// do nothing
}

inline void
DumpCB_After(void)
{
	return;	// do nothing
}

BYTE*
CopyRam (BYTE* tgtBuffer, DWORD ramStart, ULONG count)
{
    BYTE*	retBuff;
	DWORD   ramBase;

	if (tgtBuffer == NULL) return NULL;

	//Determine if were dumping from the cached or non-cached ram area
    if (ramStart & 0x20000000)
    {
        // if bit29 is set, assume cached. Any errors in the range will be
        // caught during range checking.
        ramBase = RAM_BASE_CACHED;
    }
    else
    {
        // assume uncached (bit31 set). If bit31 is not set, then the address
        // supplied has serious problems and should be caught during the range
        // check below.
        ramBase = RAM_BASE_UNCACHED;

		// we should also make sure we "write-back" any info stored in cache
		CacheSync (CACHE_SYNC_WRITEBACK);
    }

    //Verify range is indeed referencing RAM space.
	if ( (ramStart < ramBase) 
		 || ( (ramStart+count) > (ramBase + RAM_MAX) ) )
	{
		return NULL;
	}

	retBuff = (BYTE*) memcpy( tgtBuffer, (VOID*)ramStart, count );
	
	return retBuff;
}

DumpCallBack DumpCallBackBeforeFn	= DumpCB_Before;
DumpCallBack DumpCallBackDuringFn	= DumpCB_During;
DumpCallBack DumpCallBackAfterFn	= DumpCB_After;

void
DumpSetCallback(DumpCallBack callBack, int cbType)
{
	if(callBack == NULL)
	{
		// set callback(s) back to default do nothings.
		if (cbType & DUMP_CALLBACK_BEFORE)
			DumpCallBackBeforeFn = DumpCB_Before;
		
		if (cbType & DUMP_CALLBACK_DURING)
			DumpCallBackDuringFn = DumpCB_During;

		if (cbType & DUMP_CALLBACK_AFTER)
			DumpCallBackDuringFn = DumpCB_After;
	}
	else
	{
		if (cbType & DUMP_CALLBACK_BEFORE)
			DumpCallBackBeforeFn = callBack;
		
		if (cbType & DUMP_CALLBACK_DURING)
			DumpCallBackDuringFn = callBack;

		if (cbType & DUMP_CALLBACK_AFTER)
			DumpCallBackDuringFn = callBack;
	}
}

TCHAR* dumpFilePathAndName = {_T("default.bin")};

inline void
DumpSetFileNameAndPath(TCHAR* dumpFileName)
{
	if (dumpFileName)
		dumpFilePathAndName = dumpFileName;
}


int 
DumpBuffer (char* fileName, BYTE* buffer, ULONG count, int mode)
{
	DWORD	createFlag;
    HANDLE  outputFileHandle;           //Win32 file handle for output file

    DWORD   fullPagesToDump;            //Number of full pages that the memory area fills
    DWORD   partialPageToDumpSize;      //The size of the last unfilled page (if any)
    DWORD   bytesWritten;               //Number of bytes written to file for current page (NOT TOTAL)

	if ( (buffer == NULL) || (count == 0) )
		return -1;

	(*DumpCallBackBeforeFn)();

	if(mode)
	{
		createFlag = OPEN_EXISTING;
	}
	else
	{
		createFlag = CREATE_ALWAYS;
	}

    outputFileHandle = CreateFile( fileName, GENERIC_WRITE, 
                                   0, NULL, 
                                   createFlag, 
                                   0, NULL);

    if (outputFileHandle == INVALID_HANDLE_VALUE)
    {
        //if we are trying to append and this is the first time through
		//the file does not exits, so we should create it.
		if(createFlag == OPEN_EXISTING)
		{
			outputFileHandle = CreateFile( fileName, GENERIC_WRITE, 
										   0, NULL, 
										   CREATE_NEW, 
										   0, NULL);
			if (outputFileHandle == INVALID_HANDLE_VALUE)
				return -1;
		}
		else
			return -1;
    }

    //determin number of pages in requested range
    fullPagesToDump = count / PAGE_SIZE;
    partialPageToDumpSize = count - ( fullPagesToDump * PAGE_SIZE );

    //dump full pages
    for (unsigned int page=0; page<fullPagesToDump ; page++)
    {
        int ret = WriteFile(outputFileHandle, buffer, PAGE_SIZE, &bytesWritten, NULL);
		(*DumpCallBackDuringFn)();
    }
    //dump partial page
    if( partialPageToDumpSize )
    {
        int ret = WriteFile(outputFileHandle, buffer, partialPageToDumpSize, &bytesWritten, NULL);
		(*DumpCallBackDuringFn)();
    }

    CloseHandle(outputFileHandle);

	(*DumpCallBackAfterFn)();

	return 0;
}

int
DumpRam( DWORD phyStartAddress, DWORD phyEndAddress, int mode )
{
    TCHAR   outputFile[MAX_PATH];       //Path and file name where memory is dumped
    HANDLE  outputFileHandle;           //Win32 file handle for output file

//    TCHAR   msgBuf[256];                //Tempory location to hold messeages destined for display
    char    memBuf[PAGE_SIZE];          //Tranisitory location of memory to be dumped;

    DWORD   dumpSize;                   //Size (in bytes) of memory area to dump
    DWORD   fullPagesToDump;            //Number of full pages that the memory area fills
    DWORD   partialPageToDumpSize;      //The size of the last unfilled page (if any)
    DWORD   bytesWritten;               //Number of bytes written to file for current page (NOT TOTAL)

	TCHAR	outputFileDebugSeperator[] = {_T("-----")};
	static int	dumpStarted_ = 0;
	DWORD	createFlag;


	(*DumpCallBackBeforeFn)();

    strcpy( outputFile, DUMP_FILE_NAME);

	if(dumpStarted_)
	{
		createFlag = OPEN_EXISTING;
	}
	else
	{
		createFlag = CREATE_ALWAYS;
		dumpStarted_ = 1;
	}
    
    outputFileHandle = CreateFile( outputFile, 
                                   GENERIC_WRITE, 
                                   0, 
                                   NULL, 
                                   createFlag, 
                                   0, 
                                   NULL);

    if (outputFileHandle == INVALID_HANDLE_VALUE)
    {
        return -1;
    }

    //determin number of pages in requested range
    dumpSize = phyEndAddress - phyStartAddress+1;
    fullPagesToDump = dumpSize / PAGE_SIZE;
    partialPageToDumpSize = dumpSize - ( fullPagesToDump * PAGE_SIZE );

    //dump full pages
    for (unsigned int page=0; page<fullPagesToDump ; page++)
    {
        memcpy(memBuf, (char *)( phyStartAddress + (page * PAGE_SIZE) ), PAGE_SIZE);
        WriteFile(outputFileHandle, memBuf, PAGE_SIZE, &bytesWritten, NULL);
		(*DumpCallBackDuringFn)();
    }
    //dump partial page
    if( partialPageToDumpSize )
    {
        memcpy( memBuf, 
                (char *)( phyStartAddress + (fullPagesToDump * PAGE_SIZE) ), 
                partialPageToDumpSize );
        WriteFile(outputFileHandle, memBuf, partialPageToDumpSize, &bytesWritten, NULL);
		(*DumpCallBackDuringFn)();
    }

	WriteFile(outputFileHandle, outputFileDebugSeperator, 5, &bytesWritten, NULL);
	
    CloseHandle(outputFileHandle);

	(*DumpCallBackAfterFn)();

    return 0;
}

static const char *s_cpugenreg[] =
{
	"zero","at","v0","v1","a0","a1","a2","a3",
	"t0","t1","t2","t3","t4","t5","t6","t7",
	"s0","s1","s2","s3","s4","s5","s6","s7",
	"t8","t9","k0","k1","gp","sp","fp","ra"
};

static char *make_signed_hex_str_16( UINT32 value )
{
	static char s_hex[ 20 ];

	value &= 0xffff;
	if( value & 0x8000 )
	{
		sprintf( s_hex, "-$%x", ( 0 - value ) & 0x7fff );
	}
	else
	{
		sprintf( s_hex, "$%x", value & 0x7fff );
	}
	return s_hex;
}

BOOL
dumpFunction(DWORD vAddr)
{
	UINT32 op;
	UINT8 order[] = { 3, 2, 1, 0 };

	DWORD* ramAddr = (DWORD*) KernelVirt2Ram(vAddr);

	op =	( ramAddr[order[ 0 ]] << 24 ) |
			( ramAddr[order[ 1 ]] << 16 ) |
			( ramAddr[order[ 2 ]] << 8 )  |
			( ramAddr[order[ 3 ]] );

	switch( INS_OP( op ) )
	{
		case OP_ADDIU:
			printf("addiu   %s,%s,%s\n", 
				s_cpugenreg[ INS_RT( op ) ], 
				s_cpugenreg[ INS_RS( op ) ], 
				make_signed_hex_str_16( INS_IMMEDIATE( op ) ) );
			break;
		default:
			printf("Error : %08X :function vAddr = %08X\n",
				op,vAddr);
	}

	return 0;
}
