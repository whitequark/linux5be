#include <windows.h>

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "../../../include/xkernel.h"

static void usage (void)
{
	printf ("Usage: v2p [options] <virtual_address>\n\n"
			"Available options are:\n"
			" -z <proc>     - virtual_address is '0-based' and belongs to process <proc>\n"
			" -r <ram_file> - name of the 16Meg RAM file extraced from the BE300. If this\n"
			"                 option is not given, then the program will try to load a \n"
			"                 default one with the name 'RamFile.bin' in the current\n"
			"                 directory. Note: Path Seperators are '/' NOT '\\'.\n"
			"\nAll values should be entered in hexadecimal\n");
	exit (1);
}

static char *Options[]=
{
	"z","r",0
};

int main (int argc,char *argv[])
{
	
	int		currentNonOptionArgument = 0;
	int		argIndex, optionIndex;
	DWORD	virtAddress = -1;
	DWORD	physAddress;
	char*	processName = NULL;
	char*	ramFileName = "RamFile.bin";

	PKPAGE	pKPage;
	PMODULE pModule;


	for (argIndex=1; argIndex<argc; ++argIndex)
	{
		if (argv[argIndex][0]!='-')
		{
			// only 1 non-option argument is allowed
			switch (++currentNonOptionArgument)
			{
			case 1:  
				virtAddress = strtoul(argv[argIndex],0,16); 
				break;
			default: 
				usage();
			}
		}
		else
		{
			// must be an option so lets find out which one
			for (optionIndex=0; Options[optionIndex]; ++optionIndex)
				if ( strcmp(argv[argIndex]+1,Options[optionIndex]) == 0 ) 
					break; // found match

			switch (optionIndex)
			{
			case 0: // -z
				++argIndex;
				if (argIndex>argc) 	usage();  //option is missing argument
				processName = argv[argIndex];
				break;
			case 1: // -r
				++argIndex;
				if (argIndex>argc) 	usage();  //option is missing argument
				ramFileName = argv[argIndex];
				break;

			default: usage();	// unknown option
			}
		}
	}

	if (virtAddress == -1)
	{
		usage();
		return 1;
	}

//	printf("virtual address - %08X\n",virtAddress);
//
//	if(processName)
//		printf(" is '0-based' in %s\n",processName);

	pKPage = KernelInitData(ramFileName);

	if (pKPage == NULL)
	{
		printf("Error initializing Kernel Data Space with RamFile %s\n",
			ramFileName);
		return -1;		// error initializing access to kernel data page
	}

	if (processName)
	{
		pModule = KernelFindModule( pKPage , processName);
		physAddress = KernelVirt2Phys( (DWORD) MapPtrInModule( virtAddress, pModule ) );
	}
	else
		physAddress = KernelVirt2Phys( virtAddress );

	printf("Physical Address = %08X\n",physAddress);

	return 0;
}