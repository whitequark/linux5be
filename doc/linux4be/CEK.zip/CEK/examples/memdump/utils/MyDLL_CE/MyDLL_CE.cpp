// MyDLL_CE.cpp : Defines the entry point for the DLL application.
//
#include <windows.h>

#include "MyDLL_CE.h"

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}


// This is an example of an exported variable
MYDLL_CE_API int nMyDLL_CE=0;

// This is an example of an exported function.
MYDLL_CE_API int fnMyDLL_CE(void)
{
	return 42;
}

// This is the constructor of a class that has been exported.
// see MyDLL_CE.h for the class definition
CMyDLL_CE::CMyDLL_CE()
{ 
	return; 
}

