
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the MYDLL_CE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// MYDLL_CE_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef MYDLL_CE_EXPORTS
#define MYDLL_CE_API __declspec(dllexport)
#else
#define MYDLL_CE_API __declspec(dllimport)
#endif

// This class is exported from the MyDLL_CE.dll
class MYDLL_CE_API CMyDLL_CE {
public:
	CMyDLL_CE(void);
	// TODO: add your methods here.
};

extern MYDLL_CE_API int nMyDLL_CE;

MYDLL_CE_API int fnMyDLL_CE(void);

