#include <windows.h>
#include <tchar.h>
#include <commctrl.h>

//#pragma comment(lib,"comctl32.lib")

#include "../include/resource.h"
#include "../../../include/xcoredll.h"


//const char g_szClassName[] = "myWindowClass";

LPCTSTR g_szClassName = _T("myWindowClass");
HWND hprogress,mainwindow,hedit;

#define  PAGE_SIZE          4096
#define  RAM_BASE_UNCACHED  0x80000000
#define  RAM_BASE_CACHED    0xA0000000
#define  RAM_MAX            0x00FFFFFF
#define  RAM_SIZE           (RAM_MAX+1)

#define  DUMP_FILE_PATH     _T("\\Storage Card\\")   //Must end with path seperator
#define  DUMP_FILE_NAME     _T("MemDump.bin")

int
DumpRam( DWORD phyStartAddress, DWORD phyEndAddress)
{
    TCHAR   outputFile[MAX_PATH];       //Path and file name where memory is dumped
    HANDLE  outputFileHandle;           //Win32 file handle for output file

    TCHAR   msgBuf[256];                //Tempory location to hold messeages destined for display
    char    memBuf[PAGE_SIZE];          //Tranisitory location of memory to be dumped;

    DWORD   dumpSize;                   //Size (in bytes) of memory area to dump
    DWORD   fullPagesToDump;            //Number of full pages that the memory area fills
    DWORD   partialPageToDumpSize;      //The size of the last unfilled page (if any)
    DWORD   bytesWritten;               //Number of bytes written to file for current page (NOT TOTAL)

    DWORD   ramBase;                    //Base address of ram determined by the input argument <cached>
	int cyVScroll;  // height of scroll bar arrow


	RECT clientRect;

	// make sure we "write-back" any info stored in cache
	CacheSync (CACHE_SYNC_WRITEBACK);

	HINSTANCE hInstance = GetModuleHandle(NULL);

	GetClientRect(mainwindow,&clientRect);

	cyVScroll = GetSystemMetrics(SM_CYVSCROLL); 

	hprogress = CreateWindowEx(
		0, 
		PROGRESS_CLASS, 
		(LPTSTR) NULL, 
		WS_CHILD | WS_VISIBLE | PBS_SMOOTH, 
		clientRect.left, clientRect.bottom - cyVScroll, 
		clientRect.right, cyVScroll, 
		mainwindow, (HMENU) 0, hInstance, NULL); 

    _tcscpy( outputFile, DUMP_FILE_PATH);
    _tcscat( outputFile, DUMP_FILE_NAME);
    
    //Check for switched input arguments
    if ( phyStartAddress > phyEndAddress )
    {
        DWORD temp;

        temp = phyStartAddress;
        phyStartAddress = phyEndAddress;
        phyEndAddress = temp;
    }

    //Determine if were dumping from the cached or non-cached ram area
    if (phyEndAddress & 0x20000000)
    {
        // if bit29 is set, assume cached. Any errors in the range will be
        // caught during range checking.
        ramBase = RAM_BASE_CACHED;
    }
    else
    {
        // assume uncached (bit31 set). If bit31 is not set, then the address
        // supplied has serious problems and should be caught during the range
        // check below.
        ramBase = RAM_BASE_UNCACHED;
    }
    
    //Verify requested range to dump is valid
    if ( ( phyStartAddress > (ramBase + RAM_MAX) )
         || ( phyEndAddress > (ramBase + RAM_MAX) ) )
    {
        _stprintf(msgBuf, 
                  _T("Range Error On Input Arguments: 0x%0.8X - 0x%0.8X"),
                  phyStartAddress, phyEndAddress);
        MessageBox(NULL, msgBuf, _T("Error"), MB_OK);
        return -1;
    }

    outputFileHandle = CreateFile( outputFile, 
                                   GENERIC_WRITE, 
                                   0, 
                                   NULL, 
                                   CREATE_ALWAYS, 
                                   0, 
                                   NULL);

    if (outputFileHandle == INVALID_HANDLE_VALUE)
    {
        _stprintf(msgBuf, _T("CreateFile: %d"), GetLastError());
        MessageBox(NULL, msgBuf, _T("Error"), MB_OK);
        return -1;
    }

    //determin number of pages in requested range
    dumpSize = phyEndAddress - phyStartAddress+1;
    fullPagesToDump = dumpSize / PAGE_SIZE;
    partialPageToDumpSize = dumpSize - ( fullPagesToDump * PAGE_SIZE );

	// Set the range and increment of the progress bar. 
	SendMessage(hprogress, PBM_SETRANGE, 0, MAKELPARAM(0, fullPagesToDump)); 
	SendMessage(hprogress, PBM_SETSTEP, (WPARAM) 1, 0); 
	//SendMessage(hprogress, PBM_STEPIT, 0, 0);

    //dump full pages
    for (unsigned int page=0; page<fullPagesToDump ; page++)
    {
        memcpy(memBuf, (char *)( phyStartAddress + (page * PAGE_SIZE) ), PAGE_SIZE);
        WriteFile(outputFileHandle, memBuf, PAGE_SIZE, &bytesWritten, NULL);
		SendMessage(hprogress, PBM_STEPIT, 0, 0); 
		UpdateWindow(hprogress);
    }
    //dump partial page
    if( partialPageToDumpSize )
    {
       memcpy( memBuf, 
                (char *)( phyStartAddress + (fullPagesToDump * PAGE_SIZE) ), 
                partialPageToDumpSize );
        WriteFile(outputFileHandle, memBuf, partialPageToDumpSize, &bytesWritten, NULL);
    }

    CloseHandle(outputFileHandle);

    _stprintf(msgBuf, 
              _T("Completed Dump: 0x%0.8X - 0x%0.8X [0x%0.8X bytes]"),
              phyStartAddress, phyEndAddress, dumpSize);
    MessageBox(NULL, msgBuf, _T("Finished"), MB_OK);

	DestroyWindow(hprogress);

    return 0;
}
// Step 4: the Window Procedure
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    HINSTANCE hInstance = GetModuleHandle(NULL);
	
	static HWND hwndCB;


	switch(msg)
    {
		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case ID_FILE_EXIT:
					PostMessage(hwnd, WM_CLOSE, 0, 0);
					break;
				case ID_DUMPRAM:
					
//					SetWindowText(hedit, _T("Hello World2") );
//					UpdateWindow(hedit);

					//SendMessage(hprogress, PBM_STEPIT, 0, 0);
					//DumpRam( (DWORD)RAM_BASE_UNCACHED, (DWORD)RAM_BASE_UNCACHED+RAM_MAX);
					DumpRam( (DWORD)RAM_BASE_UNCACHED, (DWORD)(RAM_BASE_UNCACHED+(RAM_MAX)) );
					break;
			}
			break;
		case WM_CREATE:
			{
				RECT clientRect;
				int cyVScroll;  // height of scroll bar arrow

				InitCommonControls(); 

				GetClientRect(hwnd,&clientRect);

				cyVScroll = GetSystemMetrics(SM_CYVSCROLL); 

				mainwindow = hwnd;

//				hedit = CreateWindowEx(
//					0,
//					_T("EDIT"),
//					_T("Edit Me"),
//					WS_CHILD|WS_VISIBLE|ES_MULTILINE ,
//					0, cyVScroll+10, 
//					//clientRect.right,clientRect.bottom- cyVScroll -1,
//					clientRect.right,clientRect.bottom- cyVScroll -10,
//					hwnd, NULL, hInstance, NULL );

				hwndCB = CommandBar_Create(hInstance, hwnd, 1);			
				CommandBar_InsertMenubar(hwndCB, hInstance, IDR_MENU, 0);

							}
			break;
		case WM_LBUTTONDOWN:
			{
				TCHAR szFileName[MAX_PATH];
            
				GetModuleFileName(hInstance, szFileName, MAX_PATH);
				MessageBox(hwnd, szFileName, _T("This program is:"), MB_OK | MB_ICONINFORMATION);
			}
			break;
		case WM_CLOSE:
			DestroyWindow(hedit);
			DestroyWindow(hprogress);
            DestroyWindow(hwnd);
			break;
        case WM_DESTROY:
            PostQuitMessage(0);
			break;
        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
    LPTSTR lpCmdLine, int nCmdShow)
{
    WNDCLASS wc;
    HWND hwnd;
    MSG Msg;

		XCoreDllInit();

    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = (WNDPROC) WndProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, MAKEINTRESOURCE(IDI_ICON1));
    wc.hCursor       = 0;
    wc.hbrBackground = (HBRUSH) GetStockObject(WHITE_BRUSH);
	wc.lpszMenuName  = 0;
    wc.lpszClassName = g_szClassName;

    if(!RegisterClass(&wc))
    {
        MessageBox(NULL, _T("Window Registration Failed!"), _T("Error!"),
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    hwnd = CreateWindowEx(
        WS_EX_CLIENTEDGE,
        g_szClassName,
        _T("SysDump v0.1"),
		WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX,
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,
        NULL, NULL, hInstance, NULL);

    if(hwnd == NULL)
    {
        MessageBox(NULL, _T("Main Window Creation Failed!"), _T("Error!"),
            MB_ICONEXCLAMATION | MB_OK);
        return 0;
    }

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    while(GetMessage(&Msg, NULL, 0, 0) > 0)
    {
        TranslateMessage(&Msg);
        DispatchMessage(&Msg);
    }
    return Msg.wParam;
}

