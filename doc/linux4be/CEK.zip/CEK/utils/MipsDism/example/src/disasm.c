#include <stdio.h>

#define  REG_SRC(cmd) ((cmd >> 21) & 0x1F)
#define  REG_TRG(cmd) ((cmd >> 16) & 0x1F)
#define  REG_DST(cmd) ((cmd >> 11) & 0x1F)

typedef unsigned long  uint32_t;
typedef unsigned short uint16_t;

const char * get_register(unsigned reg) {
  static const char * names[] = { "zero", "at",  "v0",  "v1", "a0", "a1", "a2", "a3",
                                  "t0",   "t1",  "t2",  "t3", "t4", "t5", "t6", "t7", 
                                  "s0",   "s1",  "s2",  "s3", "s4", "s5", "s6", "s7",
                                  "t8",   "t9",  "k0",  "k1", "gp", "sp", "fp", "ra" };
  return (reg < 32) ? names[reg] : "???";
}

const char * get_cop0_reg(unsigned reg) {
  static const char * names[] = { "Index",    "Random",       "EntryLo0",   "EntryLo1",
                                  "Context",  "PageMask",     "Wired",      "???",
                                  "BadVAddr", "Count",        "EntryHi",    "Comparison",
                                  "Status",   "Cause",        "EPC",        "PRId",
                                  "Config",   "LLAddr",       "WatchLo",    "WatchHi",
                                  "XContext", "FrameMask",    "Diagnostic", "???",
                                  "???",      "PerfCounter",  "ParityErr",  "CacheErr",
                                  "TagLo",    "TagHi",        "ErrorEPC",   "???" };
  return (reg < 32) ? names[reg] : "???";
}

void print_R_type_3(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s,%s", name, get_register(REG_DST(command)),
                                get_register(REG_SRC(command)), get_register(REG_TRG(command)));
}

void print_R_type_3a(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s,%s", name, get_register(REG_DST(command)),
                                get_register(REG_TRG(command)), get_register(REG_SRC(command)));
}

void print_R_type_2(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s", name, get_register(REG_SRC(command)), get_register(REG_TRG(command)));
}

void print_shift(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s,%d", name, get_register(REG_DST(command)),
                                get_register(REG_TRG(command)), ((command & 0x7C0) >> 6));
}

void print_I_type_1(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,0x%04X", name, get_register(REG_TRG(command)), command & 0xFFFF);
}

void print_I_type_2(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s,0x%04X", name, get_register(REG_TRG(command)),
                                    get_register(REG_SRC(command)), command & 0xFFFF);
}

void print_br(uint32_t command, uint32_t addr, const char * name) {
  long offset = (long) (short) (command & 0xFFFF);
  printf("%-8s %s,%s,%08X", name, get_register(REG_SRC(command)),
                                  get_register(REG_TRG(command)), (addr + 4) + (offset << 2));
}

void print_br1(uint32_t command, uint32_t addr, const char * name) {
  long offset = (long) (short) (command & 0xFFFF);
  printf("%-8s %s,%08X", name, get_register(REG_SRC(command)), (addr + 4) + (offset << 2));
}

void print_j(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %08X", name, (addr & 0xF0000000) | ((command & 0x03FFFFFF) << 2));
}

void print_jr(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s", name, get_register(REG_SRC(command)));
}

void print_jalr(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s", name, get_register(REG_DST(command)), get_register(REG_SRC(command)));
}

void print_sw(uint32_t command, uint32_t addr, const char * name) {
  long offset = (long) (short) (command & 0xFFFF);
  printf("%-8s %s,0x%X(%s)", name, get_register(REG_TRG(command)),
                                   offset, get_register(REG_SRC(command)));
}

void print_dst(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s", name, get_register(REG_DST(command)));
}

void print_cop0_mov(uint32_t command, uint32_t addr, const char * name) {
  printf("%-8s %s,%s", name, get_register(REG_TRG(command)), get_cop0_reg(REG_DST(command)));
}

void print_special(uint32_t command, uint32_t addr) {
  if (command == 0) {
    printf("nop");
  } else {
    unsigned function = command & 0x3F;
    switch (function) {
      case 0x00:  print_shift(command, addr, "sll"); break;
      case 0x02:  print_shift(command, addr, "srl"); break;
      case 0x03:  print_shift(command, addr, "sra"); break;
      case 0x06:  print_R_type_3a(command, addr, "srlv"); break;
      case 0x07:  print_R_type_3a(command, addr, "srav"); break;
      case 0x08:  print_jr(command, addr, "jr"); break;
      case 0x09:  print_jalr(command, addr, "jalr"); break;
      case 0x0C:  printf("syscall"); break;
      case 0x0D:  printf("break"); break;
      case 0x10:  print_dst(command, addr, "mfhi"); break;
      case 0x12:  print_dst(command, addr, "mflo"); break;
      case 0x18:  print_R_type_2(command, addr, "mult"); break;
      case 0x19:  print_R_type_2(command, addr, "multu"); break;
      case 0x1A:  print_R_type_2(command, addr, "div"); break;
      case 0x1B:  print_R_type_2(command, addr, "divu"); break;
      case 0x20:  print_R_type_3(command, addr, "add"); break;
      case 0x21:  print_R_type_3(command, addr, "addu"); break;
      case 0x22:  print_R_type_3(command, addr, "sub"); break;
      case 0x23:  print_R_type_3(command, addr, "subu"); break;
      case 0x24:  print_R_type_3(command, addr, "and"); break;
      case 0x25:  print_R_type_3(command, addr, "or"); break;
      case 0x26:  print_R_type_3(command, addr, "xor"); break;
      case 0x27:  print_R_type_3(command, addr, "nor"); break;
      case 0x2A:  print_R_type_3(command, addr, "slt"); break;
      case 0x2B:  print_R_type_3(command, addr, "sltu"); break;
    }
  }
}

void print_cache(uint32_t command, uint32_t addr) {
  printf("%-8s %d,0x%X(%s)", "cache", REG_TRG(command), command & 0xFFFF, get_register(REG_SRC(command)));
}

void print_cop0(uint32_t command, uint32_t addr) {
  unsigned opcode = (REG_SRC(command));
  switch (opcode) {
    case 0x00:  print_cop0_mov(command, addr, "mfc0"); break;
    case 0x04:  print_cop0_mov(command, addr, "mtc0"); break;
  }
}

void print_regimm(uint32_t command, uint32_t addr) {
  const char * name = "???";
  unsigned opcode = (REG_TRG(command));
  long offset = (long) (short) (command & 0xFFFF);
  switch (opcode) {
    case 0x00: name = "bltz"; break;
    case 0x01: name = "bgez"; break;
    case 0x02: name = "bltzl"; break;
    case 0x03: name = "bgezl"; break;
    case 0x08: name = "tgei"; break;
    case 0x09: name = "tgeiu"; break;
    case 0x0A: name = "tlti"; break;
    case 0x0B: name = "tltiu"; break;
    case 0x0C: name = "teqi"; break;
    case 0x0E: name = "tnei"; break;
    case 0x10: name = "bltzal"; break;
    case 0x11: name = "bgezal"; break;
    case 0x12: name = "bltzall"; break;
    case 0x13: name = "bgezall"; break;
  }
  printf("%-8s %s,%08X", name, get_register(REG_SRC(command)), (addr + 4) + (offset << 2));
}

void print_command(uint32_t command, uint32_t addr) {
  unsigned opcode = command >> 26;
  switch (opcode) {
    case 0x00:  print_special(command, addr); break;
    case 0x01:  print_regimm(command, addr); break;
    case 0x02:  print_j(command, addr, "j"); break;
    case 0x03:  print_j(command, addr, "jal"); break;
    case 0x04:  print_br(command, addr, "beq"); break;
    case 0x05:  print_br(command, addr, "bne"); break;
    case 0x06:  print_br1(command, addr, "blez"); break;
    case 0x07:  print_br1(command, addr, "bgtz"); break;
    case 0x08:  print_I_type_2(command, addr, "addi"); break;
    case 0x09:  print_I_type_2(command, addr, "addiu"); break;
    case 0x0A:  print_I_type_2(command, addr, "slti"); break;
    case 0x0B:  print_I_type_2(command, addr, "sltiu"); break;
    case 0x0C:  print_I_type_2(command, addr, "andi"); break;
    case 0x0D:  print_I_type_2(command, addr, "ori"); break;
    case 0x0E:  print_I_type_2(command, addr, "xori"); break;
    case 0x0F:  print_I_type_1(command, addr, "lui"); break;
    case 0x10:  print_cop0(command, addr); break;
    case 0x14:  print_br(command, addr, "beql"); break;
    case 0x15:  print_br(command, addr, "bnel"); break;
    case 0x16:  print_br1(command, addr, "blezl"); break;
    case 0x17:  print_br1(command, addr, "bgtzl"); break;
    case 0x1A:  print_sw(command, addr, "ldl"); break;
    case 0x1B:  print_sw(command, addr, "ldr"); break;
    case 0x20:  print_sw(command, addr, "lb"); break;
    case 0x21:  print_sw(command, addr, "lh"); break;
    case 0x22:  print_sw(command, addr, "lwl"); break;
    case 0x23:  print_sw(command, addr, "lw"); break;
    case 0x24:  print_sw(command, addr, "lbu"); break;
    case 0x25:  print_sw(command, addr, "lhu"); break;
    case 0x26:  print_sw(command, addr, "lwr"); break;
    case 0x28:  print_sw(command, addr, "sb"); break;
    case 0x29:  print_sw(command, addr, "sh"); break;
    case 0x2A:  print_sw(command, addr, "swl"); break;
    case 0x2B:  print_sw(command, addr, "sw"); break;
    case 0x2C:  print_sw(command, addr, "sdl"); break;
    case 0x2D:  print_sw(command, addr, "sdr"); break;
    case 0x2E:  print_sw(command, addr, "swr"); break;
    case 0x2F:  print_cache(command, addr); break;
    case 0x37:  print_sw(command, addr, "ld"); break;
    case 0x3F:  print_sw(command, addr, "sd"); break;
  } 
}

int main(int argc, char * argv[]) {
  FILE * f;
  int rc = 0;
  uint32_t addr;

  if (argc != 3) {
    printf("Usage: disasm <filename> <address>\n");
    return 1;
  }

  f = fopen(argv[1], "rb");
  if (f == NULL) {
    perror("fopen");
    return -1;
  }

  for (addr = strtoul(argv[2], NULL, 16); ; addr += 4) {
    uint32_t command;
    if (fread(&command, sizeof(command), 1, f) != 1) {
      break;
    }    

    printf("%08X: %08X ", addr, command);
    print_command(command, addr);
    printf("\n");
  }

  if (ferror(f)) {
    perror("fread");
    rc = -1;
  }

  fclose(f);
  return rc;
}