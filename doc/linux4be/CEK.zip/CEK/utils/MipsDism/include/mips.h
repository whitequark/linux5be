#ifndef _MIPS_H
#define _MIPS_H

#include "osd_cpu.h"

enum
{
	MIPS_PC = 1,
	MIPS_DELAYPC, MIPS_DELAY,
	MIPS_HI, MIPS_LO,
	MIPS_R0, MIPS_R1,
	MIPS_R2, MIPS_R3,
	MIPS_R4, MIPS_R5,
	MIPS_R6, MIPS_R7,
	MIPS_R8, MIPS_R9,
	MIPS_R10, MIPS_R11,
	MIPS_R12, MIPS_R13,
	MIPS_R14, MIPS_R15,
	MIPS_R16, MIPS_R17,
	MIPS_R18, MIPS_R19,
	MIPS_R20, MIPS_R21,
	MIPS_R22, MIPS_R23,
	MIPS_R24, MIPS_R25,
	MIPS_R26, MIPS_R27,
	MIPS_R28, MIPS_R29,
	MIPS_R30, MIPS_R31,
	MIPS_CP0R0, MIPS_CP0R1,
	MIPS_CP0R2, MIPS_CP0R3,
	MIPS_CP0R4, MIPS_CP0R5,
	MIPS_CP0R6, MIPS_CP0R7,
	MIPS_CP0R8, MIPS_CP0R9,
	MIPS_CP0R10, MIPS_CP0R11,
	MIPS_CP0R12, MIPS_CP0R13,
	MIPS_CP0R14, MIPS_CP0R15,
	MIPS_CP0R16, MIPS_CP0R17,
	MIPS_CP0R18, MIPS_CP0R19,
	MIPS_CP0R20, MIPS_CP0R21,
	MIPS_CP0R22, MIPS_CP0R23,
	MIPS_CP0R24, MIPS_CP0R25,
	MIPS_CP0R26, MIPS_CP0R27,
	MIPS_CP0R28, MIPS_CP0R29,
	MIPS_CP0R30, MIPS_CP0R31
};

extern int mips_ICount;

#define MIPS_IRQ0	( 0 )
#define MIPS_IRQ1	( 1 )
#define MIPS_IRQ2	( 2 )
#define MIPS_IRQ3	( 3 )
#define MIPS_IRQ4	( 4 )
#define MIPS_IRQ5	( 5 )

#define MIPS_BYTE_EXTEND( a ) ( (INT32)(INT8)a )
#define MIPS_WORD_EXTEND( a ) ( (INT32)(INT16)a )

#define INS_OP( op ) ( ( op >> 26 ) & 63 )
#define INS_RS( op ) ( ( op >> 21 ) & 31 )
#define INS_RT( op ) ( ( op >> 16 ) & 31 )
#define INS_IMMEDIATE( op ) ( op & 0xffff )
#define INS_TARGET( op ) ( op & 0x3ffffff )
#define INS_RD( op ) ( ( op >> 11 ) & 31 )
#define INS_SHAMT( op ) ( ( op >> 6 ) & 31 )

#define MACC_TYPE( op ) \
	( ( ( INS_SHAMT(op) >> 4 ) & 3 ) | ( INS_SHAMT(op) & 3 ) )

#define INS_FUNCT( op ) ( op & 63 )
#define INS_CODE( op ) ( ( op >> 6 ) & 0xfffff )
#define INS_CO( op ) ( ( op >> 25 ) & 1 )
#define INS_COFUN( op ) ( op & 0x1ffffff )
#define INS_CF( op ) ( op & 63 )

#define GTE_OP( op ) ( op & 0x1f01bff )
#define GTE_SF( op ) ( ( op >> 19 ) & 1 )
#define GTE_MX( op ) ( ( op >> 17 ) & 3 )
#define GTE_V( op ) ( ( op >> 15 ) & 3 )
#define GTE_CV( op ) ( ( op >> 13 ) & 3 )
#define GTE_LM( op ) ( ( op >> 10 ) & 1 )

#define OP_SPECIAL	( 0 )
#define OP_REGIMM	( 1 )
#define OP_J		( 2 )
#define OP_JAL		( 3 )
#define OP_BEQ		( 4 )
#define OP_BNE		( 5 )
#define OP_BLEZ		( 6 )
#define OP_BGTZ		( 7 )
#define OP_ADDI		( 8 )
#define OP_ADDIU	( 9 )
#define OP_SLTI		( 10 )
#define OP_SLTIU	( 11 )
#define OP_ANDI		( 12 )
#define OP_ORI		( 13 )
#define OP_XORI		( 14 )
#define OP_LUI		( 15 )
#define OP_COP0		( 16 )

/* vr41xx: opcode 17,18 invalid */
/* vr41xx: opcode 19 reserved */

#define OP_BEQL		( 20 )
#define OP_BNEL		( 21 )
#define OP_BLEZL	( 22 )
#define OP_BGTZL	( 23 )

/* 
 * vr41xx: opcode 24,25,26,27 are only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define OP_DADDI	( 24 )
#define OP_DADDIU	( 25 )
#define OP_LDL		( 26 )
#define OP_LDR		( 27 )

/* vr41xx: opcode 28 reserved */

/* 
 * vr41xx: opcode 29 only valid when MIPS16 instruction execution
 *         is enabled.
*/
#define OP_JALX		( 29 )

/* vr41xx: opcode 30,31 reserved */

#define OP_LB		( 32 )
#define OP_LH		( 33 )
#define OP_LWL		( 34 )
#define OP_LW		( 35 )
#define OP_LBU		( 36 )
#define OP_LHU		( 37 )
#define OP_LWR		( 38 )

/* 
 * vr41xx: opcode 39 are only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define OP_LWU		( 39 )

#define OP_SB		( 40 )
#define OP_SH		( 41 )
#define OP_SWL		( 42 )
#define OP_SW		( 43 )

/* 
 * vr41xx: opcode 44,45 are only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define OP_SDL		( 44 )
#define OP_SDR		( 45 )

#define OP_SWR		( 46 )

/*
 * vr41xx: opcode 47 is only valid for processors conforming
 *         to MIPS III instruction set or later.
*/
#define OP_CACHE	( 47 )

/* vr41xx: opcode 48 reserved */
/* vr41xx: opcode 49,50 invalid */
/* vr41xx: opcode 51,52 reserved */
/* vr41xx: opcode 53,54 invalid */

/* 
 * vr41xx: opcode 55 is only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define OP_LD		( 55 )

/* vr41xx: opcode 56 reserved */
/* vr41xx: opcode 57,58 invalid */
/* vr41xx: opcode 59,60 reserved */
/* vr41xx: opcode 61,62 invalid */

/* 
 * vr41xx: opcode 63 is only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define OP_SD		( 63 )


/* OP_SPECIAL */
#define FUNCT_SLL	( 0 )

/* vr41xx: opcode function 1 reserved */

#define FUNCT_SRL	( 2 )
#define FUNCT_SRA	( 3 )
#define FUNCT_SLLV	( 4 )

/* vr41xx: opcode function 5 reserved */
#define FUNCT_SRLV	( 6 )
#define FUNCT_SRAV	( 7 )

#define FUNCT_JR	( 8 )
#define FUNCT_JALR	( 9 )

/* vr41xx: opcode function 10,11 reserved */

#define FUNCT_SYSCALL ( 12 )
#define FUNCT_BREAK ( 13 )

/* vr41xx: opcode function 14 reserved */

#define FUNCT_SYNC	( 15 )
#define FUNCT_MFHI	( 16 )
#define FUNCT_MTHI	( 17 )
#define FUNCT_MFLO	( 18 )
#define FUNCT_MTLO	( 19 )

/* 
 * vr41xx: opcode 20 is only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DSLLV ( 20 )

/* vr41xx: opcode function 21 reserved */

/* 
 * vr41xx: opcode 22,23 is only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DSRLV ( 22 )
#define FUNCT_DSRAV ( 23 )

#define FUNCT_MULT	( 24 )
#define FUNCT_MULTU ( 25 )
#define FUNCT_DIV	( 26 )
#define FUNCT_DIVU	( 27 )

/* 
 * vr41xx: opcode 28,29,30,31 is only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DMULT ( 28 )
#define FUNCT_DMULTU ( 29 )
#define FUNCT_DDIV	( 30 )
#define FUNCT_DDIVU ( 31 )

#define FUNCT_ADD	( 32 )
#define FUNCT_ADDU	( 33 )
#define FUNCT_SUB	( 34 )
#define FUNCT_SUBU	( 35 )
#define FUNCT_AND	( 36 )
#define FUNCT_OR	( 37 )
#define FUNCT_XOR	( 38 )
#define FUNCT_NOR	( 39 )

/*
 * vr41xx: opcode function 40 41 vaild on 
 *         vr4121,vr4122,vr4131,vr4181a
*/
#define FUNCT_MACC	( 40 )
#define FUNCT_DMACC ( 41 )

#define FUNCT_SLT	( 42 )
#define FUNCT_SLTU	( 43 )

/* 
 * vr41xx: opcode 44,45,46,47 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DADD	( 44 )
#define FUNCT_DADDU	( 45 )
#define FUNCT_DSUB	( 46 )
#define FUNCT_DSUBU	( 47 )

#define FUNCT_TGE	( 48 )
#define FUNCT_TGEU	( 49 )
#define FUNCT_TLT	( 50 )
#define FUNCT_TLTU	( 51 )
#define FUNCT_TEQ	( 52 )

/* vr41xx: opcode function 53 reserved */

#define FUNCT_TNE	( 54 )

/* vr41xx: opcode function 55 reserved */

/* 
 * vr41xx: opcode 56 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DSLL	( 56 )

/* vr41xx: opcode function 57 reserved */

/* 
 * vr41xx: opcode 58,59,60 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DSRL	( 58 )
#define FUNCT_DSRA	( 59 )
#define FUNCT_DSLL32 ( 60 )

/* vr41xx: opcode function 61 reserved */

/* 
 * vr41xx: opcode 62,63 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define FUNCT_DSRL32 ( 62 )
#define FUNCT_DSRA32 ( 63 )


/* OP_REGIMM */
#define RT_BLTZ		( 0 )
#define RT_BGEZ		( 1 )
#define RT_BLTZL	( 2 )
#define RT_BGEZL	( 3 )

/* vr41xx: opcode regimm 4,5,6,7 reserved */

#define RT_TGEI		( 8 )
#define RT_TGEIU	( 9 )
#define RT_TLTI		( 10 )
#define RT_TLTIU	( 11 )
#define RT_TEQI		( 12 )

/* vr41xx: opcode regimm 13 reserved */

#define RT_TNEI		( 14 )

/* vr41xx: opcode regimm 15 reserved */

#define RT_BLTZAL	( 16 )
#define RT_BGEZAL	( 17 )
#define RT_BLTZALL	( 18 )
#define RT_BGEZALL	( 19 )

/* vr41xx: opcode regimm 20 through 31 reserved */


/* OP_COP0 rs */
#define RS_MF		( 0 )

/* 
 * vr41xx: OP_COP0 rs 1 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define RS_DMF		( 1 )

/* vr41xx: OP_COP0 rs 2,3 reserved */

#define RS_MT		( 4 )

/* 
 * vr41xx: OP_COP0 rs 5 only valid in 64-bit mode 
 *         or 32-bit Kernel mode.
*/
#define RS_DMT		( 5 )

/* vr41xx: OP_COP0 rs 6,7 reserved */

#define RS_BC		( 8 )

/* vr41xx: OP_COP0 rs 9 through 15 reserved */

#define RS_CO		( 16 )

/* vr41xx: OP_COP0 rs 17 through 31 reserved */

/* OP_COP0 rt = RS_BC */
#define RT_BCF		( 0 )
#define RT_BCT		( 1 )
#define RT_BCFL		( 2 )
#define RT_BCTL		( 3 )

/* vr41xx: OP_COP0 rt = RS_BC, 4 through 31 reserved */

/* OP_COP0 rt = RS_CO (CP0 Functions)*/

/* vr41xx: OP_COP0 rt = RS_CO, 0 invalid */

#define CO_TLBR		( 1 )
#define CO_TLBWI	( 2 )

/* vr41xx: OP_COP0 rt = RS_CO, 3,4,5 invalid */

#define CO_TLBWR	( 6 )

/* vr41xx: OP_COP0 rt = RS_CO, 7 invalid */

#define CO_TLBP		( 8 )

/* vr41xx: OP_COP0 rt = RS_CO, 9 through 15 invalid */
/* vr41xx: OP_COP0 rt = RS_CO, 16 reserved */
/* vr41xx: OP_COP0 rt = RS_CO, 17 through 23 invalid */

#define CO_ERET		( 24 )

/* vr41xx: OP_COP0 rt = RS_CO, 25 through 32 invalid */

#define CO_STANDBY	( 33 )
#define CO_SUSPEND	( 34 )
#define CO_HIBERNATE ( 35 )

/* vr41xx: OP_COP0 rt = RS_CO, 36 through 63 invalid */


#ifdef LSB_FIRST
#define MIPS_READ_LONG(a)		(*(UINT32 *)(a))
#define MIPS_WRITE_LONG(a,d) 	(*(UINT32 *)(a) = (d))
#else
#define MIPS_READ_LONG(a)		((*(UINT16 *)(a+2))<<16)|(*(UINT16 *)(a))
#define MIPS_WRITE_LONG(a,d)	*(UINT16 *)(a+2) = d>>16; *(UINT16 *)(a) = d & 0xffff
#endif

#define mips_readop32(A)	MIPS_READ_LONG(&OP_ROM[A])
extern void mips_stop(void);

extern void mips_init(void);
extern void mips_reset(void *param);
extern void mips_exit(void);
extern int mips_execute(int cycles);
extern unsigned mips_get_context(void *dst);
extern void mips_set_context(void *src);
extern unsigned mips_get_reg(int regnum);
extern void mips_set_reg(int regnum, unsigned val);
extern void mips_set_irq_line(int irqline, int linestate);
extern void mips_set_irq_callback(int (*callback)(int irqline));
extern const char *mips_info(void *context, int regnum);
extern unsigned mips_dasm(char *buffer, unsigned pc);

#ifdef MAME_DEBUG
extern unsigned DasmMIPS(char *buff, unsigned _pc);
#endif

#if HAS_PSXCPU

#define psxcpu_ICount                   mips_ICount

#define psxcpu_reset mips_reset
#define psxcpu_exit mips_exit
#define psxcpu_execute mips_execute
#define psxcpu_get_context mips_get_context
#define psxcpu_set_context mips_set_context
#define psxcpu_get_reg mips_get_reg
#define psxcpu_set_reg mips_set_reg
#define psxcpu_set_irq_line mips_set_irq_line
#define psxcpu_set_irq_callback mips_set_irq_callback
#define psxcpu_state_save mips_state_save
#define psxcpu_state_load mips_state_load
#define psxcpu_info mips_info
#define psxcpu_dasm mips_dasm

#endif

#endif
