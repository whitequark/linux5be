#if !defined(DYNARRAY_H)
#define DYNARRAY_H


// replace at()?? with grow and shrink methodology

template <class ARYTYPE>
class DynArray
{
public:
	/** Destructor. */
	~DynArray( void );

	/**
	 * Default constructor.
	 *  optionally specify initial capacity and reallocation increment.
	*/
	DynArray( size_t capacity = 0, size_t increment = 0 );

	/** Construct from a constant buffer of elements*/
	DynArray( const ARYTYPE* buff);

	/** 
	 * Copy constructor.
	 *  The initial capacity is the current capacity of the duplicated array.
	*/
	DynArray( const DynArray<ARYTYPE>& );

	/** class to type conversion */
	inline operator ARYTYPE* () const;

	/** String extension */
	//@{
	friend DynArray<ARYTYPE>& operator + ( const DynArray<ARYTYPE> &, const DynArray<ARYTYPE> & );
	friend DynArray<ARYTYPE>& operator + ( const DynArray<ARYTYPE> &, const ARYTYPE* );
	friend DynArray<ARYTYPE>& operator + ( const ARYTYPE*, const DynArray<ARYTYPE> & );
	//@}

	/** Assignment/copy operator. does not decrease the capacity. */
	//@{
	DynArray<ARYTYPE>&		operator=( const DynArray<ARYTYPE> & );
	DynArray<ARYTYPE>&		operator=( const ARYTYPE* );
	DynArray<ARYTYPE>&		operator=( const ARYTYPE );
	//@}
	/** String extension */
	//@{
	DynArray<ARYTYPE>&		operator+=( const DynArray<ARYTYPE> &);
	DynArray<ARYTYPE>&		operator+=( const ARYTYPE );
	DynArray<ARYTYPE>&		operator+=( const ARYTYPE* );
	//@}

	/** Efficient array operator (const version): no bounds checking. */
	inline ARYTYPE		operator ()( size_t index ) const;
	/** Efficient array operator (non-const version): no bounds checking. */
	inline ARYTYPE&	operator ()( size_t index );
	/** Bounds-checking array operator (const version): throws sxBoundsError.*/
	ARYTYPE		operator []( size_t index ) const;
	/** Bounds-checking array operator (non-const version): throws sxBoundsError.
	*/
	ARYTYPE&	operator []( size_t index );

	/** Comparison operators */
	//@{
	int			operator == ( const DynArray<ARYTYPE> &) const;
	int			operator == ( const ARYTYPE *) const;
	int			operator != ( const DynArray<ARYTYPE> &) const;
	int			operator != ( const ARYTYPE *) const;
	//@}

	void		clear( void );

	/** 
	 * Insert new array elements.
	 *  count specifies the number of new elements, and offset specifies
	 *  where in the array to insert them.  By default the new elements
	 *  are appended.  The fill value, if defined, is the initializer
	 *  for the new elements.  offset refers to the end of the array:
	 *  the first new element is located at index (length - offset).
	 *  Returns the new length.  Throws sxBoundsError if offset is
	 *  greater than length.
	 * child class should derive a public function which sets up the default
	 * filler and then call the base classes member function.
	*/
	size_t		insert( size_t count, size_t offset = 0);

	/** 
	 * Bounds-adjusting array operator.  Returns the array
	 *  element at the specified index, extending the array as necessary
	 *  to bring it within bounds.  The fill value, if defined, is the
	 *  initializer for any new elements. 
	*/
	ARYTYPE&		at( size_t index );

	/** Returns current occupied length of array */
	inline size_t length( void ) const;

	/** 
	 * Append method. efficiently insert given element at end of array.
	 *  Avoids redundant initialization of new array element, except for
	 *  when a reallocation is required.  Returns the new length.
	*/
	size_t		append( const ARYTYPE );

	/** 
	 * Append method for binary data.  Adds the contents of the given
	 *  buffer to the string byte by byte. Returns the new length. 
	*/
	inline size_t append( ARYTYPE *buf, const int len );

	/** 
	 * Remove array elements.
	 *  count specifies the number of elements to remove, and offset
	 *  specifies which elements to remove.  By default elements are
	 *  removed from the end of the array.  The unused capacity grows by
	 *  this amount.  offset refers to the end of the array: the first
	 *  removed element is located at index (length - offset - count).
	 *  Returns the new length.  Throws sxBoundsError if (offset+count)
	 *  is greater than length. 
	*/
	size_t		cut( size_t count, size_t offset = 0 );

	/** 
	 * Removes the element specified by offset.
	 *  This is basically a wrapper for the cut method
	 *  <pre>
	 *  cut(1, length-offset-1)
	 *  </pre>
	*/
	void		remove( size_t offset, size_t count = 1 );

	/** return the string itself */
	inline ARYTYPE* data() const;

	/** return true if string is empty, false if not */
	inline bool	empty() const;

	ARYTYPE		filler_;		// default fill type for insertions

protected:
	friend  size_t	getBufferLength(const ARYTYPE* buffer);
	friend  int		compareBuffer( const ARYTYPE *s1, const ARYTYPE *s2 );

private:

	size_t		increment_;		// linear growth increment
	ARYTYPE*	vector_;		// dynamic array of elements
	size_t		length_;		// occupied length of vector
	size_t		capacity_;		// allocated length of vector
};


#include "DynArray.inl"		// seperate definition from implimentation for inline's
#include "DynArray.imp"		// template function implimentation.

// some macro's which ease implementing derived operators
#define DYNARRAY_OP_DEF(cl,T,op,arg)							\
	cl& operator op ( const arg orig)							\
	{															\
		return (cl&) ((*this).DynArray<T>::operator op (orig)); \
	} 


#endif  /* !defined(DYNARRAY_H) */