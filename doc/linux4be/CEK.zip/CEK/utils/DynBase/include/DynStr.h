#if !defined(DYNSTR_H)
#define DYNSTR_H

#include "DynArray.h"

class DynStr : public DynArray<char>
{
public:
	~DynStr();
	DynStr( size_t capacity = 0, size_t increment = 0 );
	DynStr(const DynStr& orig);
	DynStr( const char * );

	// type conversion to wide charater type
	// non-constant so will change if casting operator is later called.
	operator wchar_t* ()
	{
		if (wvector_) free(wvector_);

		wvector_ = (wchar_t*) malloc ( this->length() * sizeof(wchar_t) + 2);

		mbstowcs( wvector_, this->data() , this->length() );

		wvector_[this->length()] = L'\0';
		
		return wvector_;
	}

	size_t		insert( size_t count, size_t offset = 0, char c = ' ' );
	
	DynStr&		operator = ( const int );
	DynStr&		operator += ( const int );

	DYNARRAY_OP_DEF(DynStr,char,=,DynStr&);
	DYNARRAY_OP_DEF(DynStr,char,=,char*);
	DYNARRAY_OP_DEF(DynStr,char,=,char);

	DYNARRAY_OP_DEF(DynStr,char,+=,DynStr&);
	DYNARRAY_OP_DEF(DynStr,char,+=,char*);
	DYNARRAY_OP_DEF(DynStr,char,+=,char);

private:
	// pointer to wide-character representation of character string.
	// this is set during (wchar_t*) casts. and must be freed when
	// the class is destructed
	wchar_t*	wvector_;

};

#endif  // !defined(DYNSTR_H)