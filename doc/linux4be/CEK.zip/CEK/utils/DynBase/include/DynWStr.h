#if !defined(DYNWSTR_H)
#define DYNWSTR_H

#include "DynArray.h"

class DynWStr : public DynArray<wchar_t>
{
public:
	~DynWStr();
	DynWStr( const DynWStr& orig);
	DynWStr( size_t capacity = 0, size_t increment = 0 );
	DynWStr( const wchar_t * );

	// type conversion to wide charater type
	// non-constant so will change if casting operator is later called.
	operator char* ()
	{
		if (mbvector_) free(mbvector_);

		mbvector_ = (char*) malloc ( this->length() * sizeof(char) + 1);

		wcstombs( mbvector_, this->data() , this->length() );

		mbvector_[this->length()] = '\0';
		
		return mbvector_;
	}


	size_t		insert( size_t count, size_t offset = 0, wchar_t c = L' ' );

	DynWStr&		operator = ( const int );
	DynWStr&		operator += ( const int );

	DYNARRAY_OP_DEF(DynWStr,wchar_t,=,DynWStr&);
	DYNARRAY_OP_DEF(DynWStr,wchar_t,=,wchar_t*);
	DYNARRAY_OP_DEF(DynWStr,wchar_t,=,wchar_t);

	DYNARRAY_OP_DEF(DynWStr,wchar_t,+=,DynWStr&);
	DYNARRAY_OP_DEF(DynWStr,wchar_t,+=,wchar_t*);
	DYNARRAY_OP_DEF(DynWStr,wchar_t,+=,wchar_t);

private:
	// pointer to wide-character representation of character string.
	// this is set during (wchar_t*) casts. and must be freed when
	// the class is destructed
	char*	mbvector_;

};

#endif  // !defined(DYNWSTR_H)