#include <stdlib.h>
#include <stdio.h>

#include "../include/DynStr.h"
#include "../include/DynWStr.h"


void main(void)
{

	DynStr myString1;//, myString2;
	DynStr myString2;

	printf("*** \n");

	DynStr myString("[myString ]");
	printf("*** \n");

	DynWStr myWString1;//,myWString2;
	printf("*** \n");

	DynWStr myWString(L"[myWString]");

	printf("*** \n");
	myString1 = "Hello World from " + myString;
	myString1 += "<END>";
	printf("*** \n");
	myWString1 = L"Hello World from " + myWString;
	printf("*** \n");


	myString1 += 5;
	printf("*** \n");
	myWString1 += 6;

	myString2 = "mystring2 text";

	printf("*** \n");
	printf ( "%s\n", (char*)myString1 );
	printf ( "%s\n", (char*)myWString1 );
	printf("*** \n");

	wprintf ( L"%s\n", (wchar_t*)myWString1 );
	wprintf ( L"%s\n", (wchar_t*)myString1 );
	printf("*** \n");

	printf("*** \n");
	printf ( "%s\n", (char*)myString2 );

	return;
}