#include "../include/DynArray.h"
#include "../include/DynStr.h"

DynStr::~DynStr()
{
	if (wvector_) free (wvector_);
}

// default constructor
DynStr::DynStr( size_t capacity, size_t increment) : 
	DynArray<char>(capacity,increment) 
{  
	wvector_ = NULL;
}

// construct with a string
DynStr::DynStr( const char * str ) : DynArray<char>(str)
{  
	wvector_ = NULL;
}

// copy construtor
DynStr::DynStr( const DynStr& orig ) : DynArray<char>(orig) 
{  
	wvector_ = NULL;
}

size_t
DynStr::insert( size_t count, size_t offset, char c)
{
	filler_ = c;
	return insert(count,offset);
}

inline size_t
getBufferLength(const char* buffer)
{
	return strlen(buffer);
}

inline int
compareBuffer(const char* s1, const char* s2)
{
	return strcmp(s1,s2);
}


DynStr&	
DynStr::operator=( const int orig ) 
{
	clear();
	*this += orig;
	return *this;
}

DynStr&
DynStr::operator+=( const int orig )
{
	char str[50];
	sprintf(str,"%d",orig);
	
	/* must explicitly call the base class operator+=() */
	(*this).DynArray<char>::operator +=(str);

	return *this;
}

