#include "../include/DynArray.h"
#include "../include/DynWStr.h"

DynWStr::~DynWStr()
{  
	if (mbvector_) free (mbvector_);
}

DynWStr::DynWStr( size_t capacity, size_t increment ) : 
	DynArray<wchar_t>(capacity,increment) 
{  
	mbvector_ = NULL;
}

DynWStr::DynWStr( const wchar_t * str ) : DynArray<wchar_t>(str) 
{  
	mbvector_ = NULL;
}

// construct with a string
DynWStr::DynWStr( const DynWStr& orig ) : DynArray<wchar_t>(orig) 
{  
	mbvector_ = NULL;
}

size_t
DynWStr::insert( size_t count, size_t offset, wchar_t c)
{
	filler_ = c;
	return insert(count,offset);
}

size_t
getBufferLength(const wchar_t* buffer)
{
	return wcslen(buffer);
}

int
compareBuffer(const wchar_t* s1, const wchar_t* s2)
{
	return wcscmp(s1,s2);
}

DynWStr&
DynWStr::operator +=( const int orig )
{
	wchar_t str[50];
	swprintf(str,L"%d",orig);

	/* must explicitly call the base class operator+=() */
	(*this).DynArray<wchar_t>::operator +=(str);
//	*this += str;

	return *this;
}

DynWStr&	
DynWStr::operator =( const int orig ) 
{
	clear();
	*this += orig;
	return *this;
}

